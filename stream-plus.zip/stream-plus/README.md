# Stream Plus

Sistema web de streaming (canais ao vivo, filmes, séries, novelas, animes) com painel administrativo e painel do cliente.

## Stack

- **Next.js 14** (App Router, TypeScript) — front-end e back-end no mesmo projeto
- **PostgreSQL + Prisma** — banco de dados
- **NextAuth.js** — autenticação (cliente e ADM com níveis de acesso)
- **Stripe** (ou Mercado Pago/Pagar.me) — assinaturas e pagamentos
- **hls.js** — player para canais ao vivo (URL de reprodução HLS já pronta)
- **Cloudflare Stream / Mux** — hospedagem e entrega de filmes e séries sob demanda
- **Tailwind CSS** — estilização, seguindo a paleta do design (fundo escuro, roxo/azul)

## Estrutura

```
prisma/schema.prisma    → modelo de dados completo (users, plans, subscriptions,
                           payments, movies, series, seasons, episodes, channels,
                           myList, watchHistory, devices, banners, appearance)
src/app/                → rotas (App Router)
src/lib/prisma.ts       → cliente Prisma
src/components/         → componentes de UI
```

## Passo a passo para rodar

1. Instalar dependências:
   ```
   npm install
   ```
2. Copiar `.env.example` para `.env` e preencher:
   - `DATABASE_URL` — string de conexão do Postgres (Neon, Supabase ou Railway)
   - `NEXTAUTH_SECRET` — gerar com `openssl rand -base64 32`
   - Chaves do Stripe (ou gateway escolhido)
   - Credenciais do Cloudflare Stream/Mux
3. Criar as tabelas no banco:
   ```
   npx prisma migrate dev --name init
   ```
4. Rodar o projeto:
   ```
   npm run dev
   ```
5. (Opcional) Para fazer upload direto de arquivos de vídeo pelo painel ADM
   em vez de colar URLs, crie uma conta no Cloudflare Stream e preencha no
   `.env`: `CLOUDFLARE_ACCOUNT_ID` e `CLOUDFLARE_STREAM_API_TOKEN`.
   Sem isso, o campo de "colar URL do vídeo" continua funcionando normalmente.

## Próximos passos sugeridos

- [ ] Autenticação (NextAuth + páginas de login cliente/ADM)
- [ ] CRUD de filmes, séries, temporadas/episódios e canais no painel ADM
- [ ] Home do cliente (destaques, continuar assistindo, catálogo por categoria)
- [ ] Player de vídeo (hls.js para canais, player HLS para filmes/séries)
- [ ] Integração de pagamentos e webhook de confirmação
- [ ] Controle de dispositivos e sessões simultâneas
