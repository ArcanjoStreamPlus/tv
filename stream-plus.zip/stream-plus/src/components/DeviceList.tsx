"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Device = {
  id: string;
  deviceName: string;
  location: string | null;
  lastActive: string;
  status: "ATIVO" | "INATIVO";
};

export default function DeviceList({ devices }: { devices: Device[] }) {
  const router = useRouter();
  const [removingId, setRemovingId] = useState<string | null>(null);

  async function handleRemove(id: string) {
    setRemovingId(id);
    await fetch(`/api/devices/${id}`, { method: "DELETE" });
    setRemovingId(null);
    router.refresh();
  }

  return (
    <ul className="space-y-2">
      {devices.map((device) => (
        <li
          key={device.id}
          className="flex items-center justify-between bg-surface rounded-md px-4 py-3"
        >
          <div>
            <p className="text-sm font-medium">{device.deviceName}</p>
            <p className="text-xs text-textMuted/50">
              {device.location ?? "Localização desconhecida"} · Última
              atividade:{" "}
              {new Date(device.lastActive).toLocaleString("pt-BR")}
            </p>
          </div>
          <button
            onClick={() => handleRemove(device.id)}
            disabled={removingId === device.id}
            className="text-xs bg-red-600/80 hover:bg-red-600 transition rounded-md px-3 py-1.5 font-medium"
          >
            {removingId === device.id ? "Encerrando..." : "Encerrar sessão"}
          </button>
        </li>
      ))}
    </ul>
  );
}
