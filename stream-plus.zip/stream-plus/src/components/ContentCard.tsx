import Link from "next/link";

type ContentCardProps = {
  id: string;
  title: string;
  coverUrl?: string | null;
  type: "movie" | "series";
  subtitle?: string; // ex: "T1 · 9 episódios" ou "2023 · Drama"
  progressPercent?: number; // exibe barra de "continuar assistindo"
};

export default function ContentCard({
  id,
  title,
  coverUrl,
  type,
  subtitle,
  progressPercent,
}: ContentCardProps) {
  const href = `/titulo/${type}/${id}`;

  return (
    <Link
      href={href}
      className="group flex-shrink-0 w-36 sm:w-44 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-lg"
    >
      <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-surface">
        {coverUrl ? (
          // capas vêm de URLs externas cadastradas no ADM
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={coverUrl}
            alt={title}
            className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-textMuted/40 text-xs px-2 text-center">
            {title}
          </div>
        )}

        {typeof progressPercent === "number" && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
            <div
              className="h-full bg-primary"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        )}
      </div>

      <p className="mt-2 text-sm font-medium truncate">{title}</p>
      {subtitle && (
        <p className="text-xs text-textMuted/50 truncate">{subtitle}</p>
      )}
    </Link>
  );
}
