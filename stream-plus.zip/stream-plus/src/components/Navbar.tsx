"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { Search, Bell, User, X } from "lucide-react";

const NAV_ITEMS = [
  { href: "/", label: "Início" },
  { href: "/filmes", label: "Filmes" },
  { href: "/series", label: "Séries" },
  { href: "/canais", label: "Canais" },
];

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim().length >= 2) {
      router.push(`/buscar?q=${encodeURIComponent(query.trim())}`);
      setSearchOpen(false);
    }
  }

  return (
    <header className="sticky top-0 z-50 bg-background/90 backdrop-blur border-b border-white/5">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 sm:px-6 h-16">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-sm bg-gradient-to-br from-primary to-secondary rotate-45" />
            <span className="font-bold text-lg tracking-tight">
              Stream<span className="text-primary">Plus</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm">
            {NAV_ITEMS.map((item) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={
                    active
                      ? "text-white font-medium"
                      : "text-textMuted/60 hover:text-white transition"
                  }
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="flex items-center gap-4 text-textMuted/80">
          {searchOpen ? (
            <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar filmes, séries..."
                className="bg-surface border border-white/10 rounded-md px-3 py-1.5 text-sm w-40 sm:w-56"
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                aria-label="Fechar busca"
                className="hover:text-white transition"
              >
                <X size={18} />
              </button>
            </form>
          ) : (
            <button
              aria-label="Buscar"
              onClick={() => setSearchOpen(true)}
              className="hover:text-white transition"
            >
              <Search size={18} />
            </button>
          )}

          <Link href="/notificacoes" aria-label="Notificações" className="hover:text-white transition">
            <Bell size={18} />
          </Link>
          <Link
            href="/perfil"
            aria-label="Meu perfil"
            className="w-8 h-8 rounded-full bg-surface flex items-center justify-center hover:ring-2 hover:ring-primary/60 transition"
          >
            <User size={16} />
          </Link>
        </div>
      </div>
    </header>
  );
}
