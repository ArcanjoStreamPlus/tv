import ContentCard from "./ContentCard";

type ContentRowItem = {
  id: string;
  title: string;
  coverUrl?: string | null;
  type: "movie" | "series";
  subtitle?: string;
  progressPercent?: number;
};

type ContentRowProps = {
  title: string;
  items: ContentRowItem[];
};

export default function ContentRow({ title, items }: ContentRowProps) {
  if (items.length === 0) return null;

  return (
    <section className="mb-8">
      <h2 className="text-lg font-semibold mb-3 px-4 sm:px-6">{title}</h2>
      <div className="flex gap-4 overflow-x-auto px-4 sm:px-6 pb-2 scrollbar-hide">
        {items.map((item) => (
          <ContentCard key={`${item.type}-${item.id}`} {...item} />
        ))}
      </div>
    </section>
  );
}
