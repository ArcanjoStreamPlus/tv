"use client";

import { useEffect, useRef } from "react";
import Hls from "hls.js";

type VodPlayerProps = {
  videoUrl: string;
  contentId: string;
  contentType: "movie" | "episode";
};

export default function VodPlayer({
  videoUrl,
  contentId,
  contentType,
}: VodPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls | null = null;

    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = videoUrl;
    } else if (Hls.isSupported()) {
      hls = new Hls();
      hls.loadSource(videoUrl);
      hls.attachMedia(video);
    }

    // salva o progresso a cada 10s, pra alimentar "Continuar assistindo"
    const interval = setInterval(() => {
      if (video.currentTime > 0) {
        fetch("/api/watch-history", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contentId,
            contentType,
            progressSeconds: Math.floor(video.currentTime),
          }),
        }).catch(() => {
          // falha silenciosa: não deve interromper a reprodução
        });
      }
    }, 10000);

    return () => {
      clearInterval(interval);
      hls?.destroy();
    };
  }, [videoUrl, contentId, contentType]);

  return (
    <video
      ref={videoRef}
      controls
      autoPlay
      className="w-full aspect-video bg-black rounded-lg"
    />
  );
}
