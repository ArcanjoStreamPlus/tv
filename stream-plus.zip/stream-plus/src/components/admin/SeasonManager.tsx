"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import VideoUploadField from "./VideoUploadField";

type Episode = {
  id: string;
  episodeNumber: number;
  title: string;
  videoUrl: string;
  durationMin: number | null;
};

type Season = {
  id: string;
  seasonNumber: number;
  episodes: Episode[];
};

export default function SeasonManager({
  seriesId,
  initialSeasons,
}: {
  seriesId: string;
  initialSeasons: Season[];
}) {
  const [seasons, setSeasons] = useState<Season[]>(initialSeasons);
  const [addingSeason, setAddingSeason] = useState(false);

  async function handleAddSeason() {
    setAddingSeason(true);
    const nextNumber = seasons.length + 1;

    const res = await fetch(`/api/series/${seriesId}/seasons`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seasonNumber: nextNumber, episodes: [] }),
    });

    setAddingSeason(false);

    if (res.ok) {
      const season = await res.json();
      setSeasons((prev) => [...prev, { ...season, episodes: [] }]);
    }
  }

  return (
    <div className="space-y-6">
      {seasons.map((season) => (
        <SeasonBlock
          key={season.id}
          season={season}
          onEpisodeAdded={(episode) =>
            setSeasons((prev) =>
              prev.map((s) =>
                s.id === season.id
                  ? { ...s, episodes: [...s.episodes, episode] }
                  : s
              )
            )
          }
        />
      ))}

      <button
        onClick={handleAddSeason}
        disabled={addingSeason}
        className="flex items-center gap-2 bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
      >
        <Plus size={16} />
        {addingSeason ? "Adicionando..." : "Adicionar Temporada"}
      </button>
    </div>
  );
}

function SeasonBlock({
  season,
  onEpisodeAdded,
}: {
  season: Season;
  onEpisodeAdded: (episode: Episode) => void;
}) {
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [title, setTitle] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [durationMin, setDurationMin] = useState("");

  async function handleAddEpisode(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);

    const nextNumber = season.episodes.length + 1;

    const res = await fetch(`/api/seasons/${season.id}/episodes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        episodeNumber: nextNumber,
        title,
        videoUrl,
        durationMin: durationMin ? Number(durationMin) : undefined,
      }),
    });

    setSaving(false);

    if (res.ok) {
      const episode = await res.json();
      onEpisodeAdded(episode);
      setTitle("");
      setVideoUrl("");
      setDurationMin("");
      setShowForm(false);
    }
  }

  return (
    <div className="bg-surface rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-medium text-sm">Temporada {season.seasonNumber}</h2>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="text-xs text-primary hover:underline"
        >
          + Adicionar Episódio
        </button>
      </div>

      <ul className="space-y-2 mb-3">
        {season.episodes.map((ep) => (
          <li
            key={ep.id}
            className="flex items-center justify-between bg-background rounded-md px-3 py-2 text-sm"
          >
            <span>
              {ep.episodeNumber}. {ep.title}
            </span>
            {ep.durationMin && (
              <span className="text-xs text-textMuted/50">
                {ep.durationMin} min
              </span>
            )}
          </li>
        ))}
        {season.episodes.length === 0 && (
          <p className="text-xs text-textMuted/50">
            Nenhum episódio nesta temporada ainda.
          </p>
        )}
      </ul>

      {showForm && (
        <form onSubmit={handleAddEpisode} className="space-y-2 pt-2 border-t border-white/5">
          <input
            required
            placeholder="Título do episódio"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-md bg-background border border-white/10 px-3 py-1.5 text-sm"
          />
          <VideoUploadField value={videoUrl} onChange={setVideoUrl} />
          <input
            placeholder="Duração (min)"
            type="number"
            value={durationMin}
            onChange={(e) => setDurationMin(e.target.value)}
            className="w-full rounded-md bg-background border border-white/10 px-3 py-1.5 text-sm"
          />
          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-3 py-1.5 text-xs font-semibold"
          >
            {saving ? "Salvando..." : "Salvar episódio"}
          </button>
        </form>
      )}
    </div>
  );
}
