"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function UserStatusToggle({
  userId,
  status,
}: {
  userId: string;
  status: "ATIVO" | "BLOQUEADO" | "PENDENTE";
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleToggle() {
    setLoading(true);
    await fetch(`/api/users/${userId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        status: status === "ATIVO" ? "BLOQUEADO" : "ATIVO",
      }),
    });
    setLoading(false);
    router.refresh();
  }

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className={`text-xs px-3 py-1.5 rounded-md font-medium transition ${
        status === "ATIVO"
          ? "bg-red-600/80 hover:bg-red-600"
          : "bg-green-600/80 hover:bg-green-600"
      }`}
    >
      {loading ? "..." : status === "ATIVO" ? "Bloquear" : "Desbloquear"}
    </button>
  );
}
