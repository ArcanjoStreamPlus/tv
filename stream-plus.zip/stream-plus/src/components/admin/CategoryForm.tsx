"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const TYPES = [
  { value: "FILME", label: "Filmes" },
  { value: "SERIE", label: "Séries" },
  { value: "CANAL", label: "Canais" },
  { value: "NOVELA", label: "Novelas" },
  { value: "ANIME", label: "Animes" },
  { value: "DOCUMENTARIO", label: "Documentários" },
];

export default function CategoryForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [type, setType] = useState("FILME");
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);

    const res = await fetch("/api/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, type }),
    });

    setSaving(false);

    if (res.ok) {
      setName("");
      router.refresh();
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex flex-wrap items-end gap-3 bg-surface rounded-lg p-4"
    >
      <div className="flex-1 min-w-[180px]">
        <label className="block text-xs mb-1 text-textMuted/60">Nome</label>
        <input
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nova categoria"
          className="w-full rounded-md bg-background border border-white/10 px-3 py-2 text-sm"
        />
      </div>

      <div>
        <label className="block text-xs mb-1 text-textMuted/60">Tipo</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="rounded-md bg-background border border-white/10 px-3 py-2 text-sm"
        >
          {TYPES.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
      >
        {saving ? "Salvando..." : "+ Nova Categoria"}
      </button>
    </form>
  );
}
