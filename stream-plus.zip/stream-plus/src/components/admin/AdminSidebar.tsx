"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import {
  LayoutDashboard,
  Film,
  Tv,
  Radio,
  Users,
  CreditCard,
  Package,
  Palette,
  LogOut,
  Tag,
  Image,
} from "lucide-react";

const NAV_SECTIONS = [
  {
    items: [{ href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    title: "Conteúdo",
    items: [
      { href: "/admin/filmes", label: "Filmes", icon: Film },
      { href: "/admin/series", label: "Séries", icon: Tv },
      { href: "/admin/canais", label: "Canais ao Vivo", icon: Radio },
      { href: "/admin/categorias", label: "Categorias", icon: Tag },
      { href: "/admin/banners", label: "Banners", icon: Image },
    ],
  },
  {
    title: "Gestão",
    items: [
      { href: "/admin/usuarios", label: "Usuários", icon: Users },
      { href: "/admin/assinaturas", label: "Assinaturas", icon: CreditCard },
      { href: "/admin/planos", label: "Planos", icon: Package },
      { href: "/admin/administradores", label: "Administradores", icon: Users },
    ],
  },
  {
    title: "Configurações",
    items: [
      { href: "/admin/configuracoes/pagamentos", label: "Pagamentos", icon: CreditCard },
      { href: "/admin/configuracoes/aparencia", label: "Aparência", icon: Palette },
    ],
  },
];

export default function AdminSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-56 flex-shrink-0 bg-surface min-h-screen p-4 flex flex-col justify-between">
      <div>
        <Link href="/admin/dashboard" className="flex items-center gap-2 px-2 mb-8">
          <span className="w-2.5 h-2.5 rounded-sm bg-gradient-to-br from-primary to-secondary rotate-45" />
          <span className="font-bold tracking-tight">
            Stream<span className="text-primary">Plus</span>
          </span>
        </Link>

        <nav className="space-y-6">
          {NAV_SECTIONS.map((section, i) => (
            <div key={i}>
              {section.title && (
                <p className="text-[10px] uppercase tracking-wide text-textMuted/40 px-2 mb-2">
                  {section.title}
                </p>
              )}
              <ul className="space-y-1">
                {section.items.map((item) => {
                  const active = pathname.startsWith(item.href);
                  const Icon = item.icon;
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        className={`flex items-center gap-2.5 px-2 py-2 rounded-md text-sm transition ${
                          active
                            ? "bg-primary/15 text-primary font-medium"
                            : "text-textMuted/70 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        <Icon size={16} />
                        {item.label}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>
      </div>

      <button
        onClick={() => signOut({ callbackUrl: "/admin/login" })}
        className="flex items-center gap-2.5 px-2 py-2 rounded-md text-sm text-textMuted/70 hover:bg-white/5 hover:text-white transition"
      >
        <LogOut size={16} />
        Sair
      </button>
    </aside>
  );
}
