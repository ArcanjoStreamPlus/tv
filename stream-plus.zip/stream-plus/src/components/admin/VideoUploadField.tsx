"use client";

import { useState } from "react";
import { UploadCloud } from "lucide-react";

type VideoUploadFieldProps = {
  value: string;
  onChange: (videoUrl: string) => void;
};

/**
 * Faz upload direto do navegador pro Cloudflare Stream (sem passar pelo
 * nosso servidor) e preenche o campo com a URL HLS final assim que o
 * processamento termina.
 */
export default function VideoUploadField({ value, onChange }: VideoUploadFieldProps) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);
    setProgress(0);

    try {
      const res = await fetch("/api/upload/video", { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error ?? "Erro ao iniciar upload");
      }

      await uploadWithProgress(data.uploadUrl, file, setProgress);

      onChange(data.playbackUrl);
    } catch (err: any) {
      setError(err.message ?? "Erro ao fazer upload do vídeo.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      <div className="flex items-center gap-3">
        <label className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition rounded-md px-3 py-2 text-sm cursor-pointer">
          <UploadCloud size={16} />
          {uploading ? `Enviando... ${progress}%` : "Enviar arquivo de vídeo"}
          <input
            type="file"
            accept="video/*"
            onChange={handleFileChange}
            disabled={uploading}
            className="hidden"
          />
        </label>
        {value && !uploading && (
          <span className="text-xs text-green-400">Vídeo pronto ✓</span>
        )}
      </div>

      <p className="text-xs text-textMuted/50 mt-1">
        Ou cole diretamente a URL HLS (.m3u8) abaixo, se já tiver o vídeo
        hospedado em outro lugar.
      </p>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="https://.../video.m3u8"
        className="w-full mt-1 rounded-md bg-background border border-white/10 px-3 py-2 text-sm"
      />

      {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
    </div>
  );
}

function uploadWithProgress(
  url: string,
  file: File,
  onProgress: (percent: number) => void
): Promise<void> {
  return new Promise((resolve, reject) => {
    const formData = new FormData();
    formData.append("file", file);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        onProgress(Math.round((event.loaded / event.total) * 100));
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve();
      else reject(new Error("Falha no upload do vídeo."));
    };
    xhr.onerror = () => reject(new Error("Falha no upload do vídeo."));

    xhr.send(formData);
  });
}
