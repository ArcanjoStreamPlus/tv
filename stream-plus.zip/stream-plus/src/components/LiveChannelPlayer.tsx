"use client";

import { useEffect, useRef } from "react";
import Hls from "hls.js";

type LiveChannelPlayerProps = {
  streamUrl: string;
  channelName: string;
};

/**
 * Toca o link de reprodução cadastrado no canal (HLS .m3u8).
 * Se o link cadastrado for de um embed (iframe de terceiro) em vez de
 * um .m3u8 direto, troque este componente por um <iframe src={streamUrl} />.
 */
export default function LiveChannelPlayer({
  streamUrl,
  channelName,
}: LiveChannelPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // Safari toca HLS nativamente, não precisa do hls.js
    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = streamUrl;
      return;
    }

    if (Hls.isSupported()) {
      const hls = new Hls();
      hls.loadSource(streamUrl);
      hls.attachMedia(video);
      return () => hls.destroy();
    }
  }, [streamUrl]);

  return (
    <video
      ref={videoRef}
      controls
      autoPlay
      playsInline
      className="w-full aspect-video bg-black rounded-lg"
      aria-label={`Player ao vivo - ${channelName}`}
    />
  );
}
