"use client";

import { useState } from "react";

export default function SubscriptionActions({
  planId,
  isCurrent,
}: {
  planId: string;
  isCurrent: boolean;
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubscribe() {
    setLoading(true);
    setError(null);

    const res = await fetch("/api/payments/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ planId }),
    });

    setLoading(false);

    if (!res.ok) {
      setError("Não foi possível iniciar o pagamento. Tente novamente.");
      return;
    }

    const data = await res.json();
    if (data.checkoutUrl) {
      window.location.href = data.checkoutUrl;
    }
  }

  if (isCurrent) {
    return (
      <button
        disabled
        className="bg-white/10 text-textMuted/60 rounded-md py-2 font-semibold cursor-default"
      >
        Plano atual
      </button>
    );
  }

  return (
    <div>
      <button
        onClick={handleSubscribe}
        disabled={loading}
        className="w-full bg-primary hover:opacity-90 transition rounded-md py-2 font-semibold"
      >
        {loading ? "Redirecionando..." : "Assinar"}
      </button>
      {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
    </div>
  );
}
