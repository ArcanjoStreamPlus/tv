import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";

const schema = z.object({
  contentId: z.string(),
  contentType: z.enum(["movie", "episode"]),
  progressSeconds: z.number().int().nonnegative(),
});

// POST /api/watch-history — upsert do progresso de reprodução do usuário logado
export async function POST(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const userId = (session!.user as any).id;
  const { contentId, contentType, progressSeconds } = parsed.data;

  const movieId = contentType === "movie" ? contentId : undefined;
  const episodeId = contentType === "episode" ? contentId : undefined;

  // para episódio, também precisamos ligar à série (pra aparecer em "Continuar assistindo")
  let seriesId: string | undefined;
  if (episodeId) {
    const episode = await prisma.episode.findUnique({
      where: { id: episodeId },
      include: { season: true },
    });
    seriesId = episode?.season.seriesId;
  }

  const existing = await prisma.watchHistoryItem.findFirst({
    where: { userId, ...(movieId ? { movieId } : { episodeId }) },
  });

  const item = existing
    ? await prisma.watchHistoryItem.update({
        where: { id: existing.id },
        data: { progressSeconds },
      })
    : await prisma.watchHistoryItem.create({
        data: { userId, movieId, episodeId, seriesId, progressSeconds },
      });

  return NextResponse.json(item);
}
