import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// PATCH /api/channels/:id — editar canal (ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const channel = await prisma.channel.update({
    where: { id: params.id },
    data: body,
  });

  return NextResponse.json(channel);
}

// DELETE /api/channels/:id — remover canal (ADM)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  await prisma.channel.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
