import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const channelSchema = z.object({
  name: z.string().min(1),
  coverUrl: z.string().url(),
  // Link de reprodução direto (HLS .m3u8 ou embed) — não é lista m3u.
  streamUrl: z.string().url(),
  categoryId: z.string().optional(),
  status: z.enum(["ATIVO", "INATIVO"]).optional(),
});

// GET /api/channels — lista de canais ao vivo (tela "Página de Canais")
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const categoryId = searchParams.get("categoryId");

  const channels = await prisma.channel.findMany({
    where: {
      status: "ATIVO",
      ...(categoryId && { categoryId }),
    },
    orderBy: { name: "asc" },
    include: { category: true },
  });

  return NextResponse.json(channels);
}

// POST /api/channels — cadastro de canal ao vivo (ADM)
export async function POST(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = channelSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const channel = await prisma.channel.create({ data: parsed.data });
  return NextResponse.json(channel, { status: 201 });
}
