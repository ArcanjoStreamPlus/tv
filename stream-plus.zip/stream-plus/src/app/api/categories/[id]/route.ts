import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// PATCH /api/categories/:id — editar categoria (ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const category = await prisma.category.update({
    where: { id: params.id },
    data: body,
  });

  return NextResponse.json(category);
}

// DELETE /api/categories/:id — desativa a categoria
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const category = await prisma.category.update({
    where: { id: params.id },
    data: { active: false },
  });

  return NextResponse.json(category);
}
