import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const categorySchema = z.object({
  name: z.string().min(1),
  icon: z.string().optional(),
  type: z.enum([
    "FILME",
    "SERIE",
    "CANAL",
    "NOVELA",
    "ANIME",
    "DOCUMENTARIO",
  ]),
});

// GET /api/categories — lista categorias (usado pra montar os filtros do catálogo)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const type = searchParams.get("type");

  const categories = await prisma.category.findMany({
    where: {
      active: true,
      ...(type && { type: type as any }),
    },
    orderBy: { name: "asc" },
  });

  return NextResponse.json(categories);
}

// POST /api/categories — cadastro de categoria (ADM)
export async function POST(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = categorySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const category = await prisma.category.create({ data: parsed.data });
  return NextResponse.json(category, { status: 201 });
}
