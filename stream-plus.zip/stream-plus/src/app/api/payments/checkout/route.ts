import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { Preference } from "mercadopago";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";
import { getMercadoPagoClient } from "@/lib/mercadopago";

const checkoutSchema = z.object({
  planId: z.string(),
});

// POST /api/payments/checkout
// Cria uma "subscription" PENDENTE + uma preferência de pagamento no Mercado Pago,
// e devolve a URL (init_point) pra redirecionar o cliente ao checkout.
export async function POST(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const body = await req.json();
  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const plan = await prisma.plan.findUnique({ where: { id: parsed.data.planId } });
  if (!plan || !plan.active) {
    return NextResponse.json({ error: "Plano inválido" }, { status: 400 });
  }

  const userId = (session!.user as any).id;

  // assinatura criada como PENDENTE; vira ATIVA quando o webhook confirmar o pagamento
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 30);

  const subscription = await prisma.subscription.create({
    data: {
      userId,
      planId: plan.id,
      status: "PENDENTE", // vira ATIVA quando o webhook confirmar o pagamento
      expiresAt,
    },
  });

  const payment = await prisma.payment.create({
    data: {
      subscriptionId: subscription.id,
      amount: plan.price,
      method: "PIX",
      status: "PENDENTE",
    },
  });

  const client = await getMercadoPagoClient();
  const preference = new Preference(client);

  const result = await preference.create({
    body: {
      items: [
        {
          id: plan.id,
          title: `Plano ${plan.name} - Stream Plus`,
          quantity: 1,
          unit_price: Number(plan.price),
          currency_id: "BRL",
        },
      ],
      external_reference: payment.id,
      notification_url: `${process.env.NEXTAUTH_URL}/api/payments/webhook`,
      back_urls: {
        success: `${process.env.NEXTAUTH_URL}/assinatura/sucesso`,
        failure: `${process.env.NEXTAUTH_URL}/assinatura/erro`,
        pending: `${process.env.NEXTAUTH_URL}/assinatura/pendente`,
      },
      auto_return: "approved",
    },
  });

  return NextResponse.json({
    checkoutUrl: result.init_point,
    paymentId: payment.id,
    subscriptionId: subscription.id,
  });
}
