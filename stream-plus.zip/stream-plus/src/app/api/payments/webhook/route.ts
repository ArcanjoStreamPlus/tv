import { NextRequest, NextResponse } from "next/server";
import { Payment as MPPayment } from "mercadopago";
import { prisma } from "@/lib/prisma";
import { getMercadoPagoClient } from "@/lib/mercadopago";

// POST /api/payments/webhook
// Mercado Pago chama esta rota quando o status de um pagamento muda.
// Documentação: https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/webhooks
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // O MP manda o id do pagamento em body.data.id (notificação tipo "payment")
    const mpPaymentId = body?.data?.id;
    if (!mpPaymentId) {
      return NextResponse.json({ received: true });
    }

    const client = await getMercadoPagoClient();
    const mpPayment = new MPPayment(client);
    const mpResult = await mpPayment.get({ id: mpPaymentId });

    // external_reference foi setado no checkout como o id do nosso Payment
    const localPaymentId = mpResult.external_reference;
    if (!localPaymentId) {
      return NextResponse.json({ received: true });
    }

    const localPayment = await prisma.payment.findUnique({
      where: { id: localPaymentId },
      include: { subscription: true },
    });
    if (!localPayment) {
      return NextResponse.json({ received: true });
    }

    const mpStatus = mpResult.status; // approved | pending | rejected | ...

    if (mpStatus === "approved") {
      await prisma.$transaction([
        prisma.payment.update({
          where: { id: localPayment.id },
          data: {
            status: "APROVADO",
            externalId: String(mpPaymentId),
            paidAt: new Date(),
            method: mpResult.payment_type_id === "credit_card" ? "CARTAO" : "PIX",
          },
        }),
        prisma.subscription.update({
          where: { id: localPayment.subscriptionId },
          data: { status: "ATIVA" },
        }),
      ]);

      const subscriptionWithUser = await prisma.subscription.findUnique({
        where: { id: localPayment.subscriptionId },
        include: { user: true },
      });
      if (subscriptionWithUser) {
        await prisma.notification.create({
          data: {
            userId: subscriptionWithUser.userId,
            type: "PAGAMENTO",
            title: "Pagamento aprovado",
            message: `Seu pagamento de R$ ${Number(localPayment.amount).toFixed(2)} foi confirmado.`,
          },
        });
      }
    } else if (mpStatus === "rejected") {
      await prisma.payment.update({
        where: { id: localPayment.id },
        data: { status: "RECUSADO", externalId: String(mpPaymentId) },
      });
    }
    // "pending" e outros status: não muda nada, aguarda próxima notificação

    return NextResponse.json({ received: true });
  } catch (err) {
    console.error("Erro no webhook do Mercado Pago:", err);
    // sempre retorna 200 pro MP não ficar reenviando indefinidamente por erro nosso
    return NextResponse.json({ received: true });
  }
}
