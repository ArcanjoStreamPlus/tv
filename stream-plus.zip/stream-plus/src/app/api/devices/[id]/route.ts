import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";

// DELETE /api/devices/:id — encerra a sessão de um dispositivo
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { session, error } = await requireClient();
  if (error) return error;

  const userId = (session!.user as any).id;

  const device = await prisma.device.findUnique({ where: { id: params.id } });
  if (!device || device.userId !== userId) {
    return NextResponse.json({ error: "Dispositivo não encontrado" }, { status: 404 });
  }

  await prisma.device.delete({ where: { id: params.id } });

  await prisma.notification.create({
    data: {
      userId,
      type: "DISPOSITIVO",
      title: "Dispositivo desconectado",
      message: `O dispositivo "${device.deviceName}" foi removido da sua conta.`,
    },
  });

  return NextResponse.json({ success: true });
}
