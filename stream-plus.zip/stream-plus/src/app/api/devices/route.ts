import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";

const deviceSchema = z.object({
  deviceName: z.string().min(1),
  ip: z.string().optional(),
  location: z.string().optional(),
});

// GET /api/devices — lista dispositivos do usuário logado
export async function GET() {
  const { session, error } = await requireClient();
  if (error) return error;

  const userId = (session!.user as any).id;

  const devices = await prisma.device.findMany({
    where: { userId },
    orderBy: { lastActive: "desc" },
  });

  return NextResponse.json(devices);
}

// POST /api/devices — registra o dispositivo atual (chamado no login),
// respeitando o limite do plano ativo
export async function POST(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const body = await req.json();
  const parsed = deviceSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const userId = (session!.user as any).id;

  const [activeSubscription, currentDevices] = await Promise.all([
    prisma.subscription.findFirst({
      where: { userId, status: "ATIVA" },
      include: { plan: true },
    }),
    prisma.device.count({ where: { userId, status: "ATIVO" } }),
  ]);

  const maxDevices = activeSubscription?.plan.maxDevices ?? 1;

  if (currentDevices >= maxDevices) {
    return NextResponse.json(
      {
        error: `Limite de ${maxDevices} dispositivos atingido para o seu plano. Encerre uma sessão para continuar.`,
      },
      { status: 403 }
    );
  }

  const device = await prisma.device.create({
    data: { userId, ...parsed.data },
  });

  return NextResponse.json(device, { status: 201 });
}
