import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/search?q=termo — busca por título em filmes, séries e canais
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();

  if (!q || q.length < 2) {
    return NextResponse.json({ movies: [], series: [], channels: [] });
  }

  const [movies, series, channels] = await Promise.all([
    prisma.movie.findMany({
      where: { title: { contains: q, mode: "insensitive" } },
      take: 8,
    }),
    prisma.series.findMany({
      where: { title: { contains: q, mode: "insensitive" } },
      take: 8,
    }),
    prisma.channel.findMany({
      where: { name: { contains: q, mode: "insensitive" }, status: "ATIVO" },
      take: 8,
    }),
  ]);

  return NextResponse.json({ movies, series, channels });
}
