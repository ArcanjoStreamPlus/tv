import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const schema = z.object({ email: z.string().email() });

// POST /api/auth/esqueci-senha
// Gera um token de reset válido por 1h. Em produção, este token deve ser
// enviado por e-mail (ex: via Resend/SendGrid) — aqui deixamos o envio
// como TODO, já que depende do provedor de e-mail que você for escolher.
export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });

  // sempre retorna sucesso, mesmo se o e-mail não existir — evita
  // que alguém descubra quais e-mails estão cadastrados no sistema
  if (!user) {
    return NextResponse.json({ success: true });
  }

  const resetToken = crypto.randomBytes(32).toString("hex");
  const resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000); // 1h

  await prisma.user.update({
    where: { id: user.id },
    data: { resetToken, resetTokenExpiry },
  });

  // TODO: enviar e-mail com o link contendo `resetToken`
  // Ex: `${process.env.NEXTAUTH_URL}/recuperar-senha/redefinir?token=${resetToken}`
  console.log(`[dev] Token de recuperação para ${user.email}: ${resetToken}`);

  return NextResponse.json({ success: true });
}
