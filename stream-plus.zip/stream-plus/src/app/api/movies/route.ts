import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const movieSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  coverUrl: z.string().url().optional(),
  trailerUrl: z.string().url().optional(),
  videoUrl: z.string().url(),
  genre: z.string().optional(),
  year: z.number().int().optional(),
  classification: z.string().optional(),
  featured: z.boolean().optional(),
  categoryId: z.string().optional(),
});

// GET /api/movies — catálogo público (usado no painel do cliente)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const genre = searchParams.get("genre");
  const year = searchParams.get("year");
  const categoryId = searchParams.get("categoryId");

  const movies = await prisma.movie.findMany({
    where: {
      ...(genre && { genre }),
      ...(year && { year: Number(year) }),
      ...(categoryId && { categoryId }),
    },
    orderBy: { createdAt: "desc" },
    include: { category: true },
  });

  return NextResponse.json(movies);
}

// POST /api/movies — cadastro de filme (ADM, requer permissão de conteúdo)
export async function POST(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = movieSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const movie = await prisma.movie.create({ data: parsed.data });
  return NextResponse.json(movie, { status: 201 });
}
