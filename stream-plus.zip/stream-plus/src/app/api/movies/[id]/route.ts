import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// GET /api/movies/:id — detalhes do filme (tela "Detalhes do Conteúdo")
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const movie = await prisma.movie.findUnique({
    where: { id: params.id },
    include: { category: true },
  });

  if (!movie) {
    return NextResponse.json({ error: "Filme não encontrado" }, { status: 404 });
  }
  return NextResponse.json(movie);
}

// PATCH /api/movies/:id — editar filme (ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const movie = await prisma.movie.update({
    where: { id: params.id },
    data: body,
  });

  return NextResponse.json(movie);
}

// DELETE /api/movies/:id — remover filme (ADM)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  await prisma.movie.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
