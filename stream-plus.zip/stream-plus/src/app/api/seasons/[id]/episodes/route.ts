import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const episodeSchema = z.object({
  episodeNumber: z.number().int(),
  title: z.string().min(1),
  videoUrl: z.string().url(),
  durationMin: z.number().int().optional(),
});

// POST /api/seasons/:id/episodes — adiciona um episódio à temporada informada
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = episodeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const episode = await prisma.episode.create({
    data: { seasonId: params.id, ...parsed.data },
  });

  return NextResponse.json(episode, { status: 201 });
}
