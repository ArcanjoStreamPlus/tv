import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const settingsSchema = z.object({
  publicKey: z.string().min(1),
  accessToken: z.string().min(1),
});

// GET /api/admin/payment-settings — retorna a configuração (Access Token mascarado)
export async function GET() {
  const { error } = await requireAdmin("payments:read");
  if (error) return error;

  const settings = await prisma.paymentGatewaySettings.findFirst({
    where: { provider: "mercadopago" },
  });

  if (!settings) {
    return NextResponse.json(null);
  }

  return NextResponse.json({
    publicKey: settings.publicKey,
    // nunca devolve o access token completo pro front, só uma prévia
    accessTokenPreview: `${settings.accessToken.slice(0, 8)}••••••••`,
    updatedAt: settings.updatedAt,
  });
}

// PUT /api/admin/payment-settings — salva/atualiza Public Key e Access Token
export async function PUT(req: NextRequest) {
  const { error } = await requireAdmin("payments:write");
  if (error) return error;

  const body = await req.json();
  const parsed = settingsSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const existing = await prisma.paymentGatewaySettings.findFirst({
    where: { provider: "mercadopago" },
  });

  const settings = existing
    ? await prisma.paymentGatewaySettings.update({
        where: { id: existing.id },
        data: parsed.data,
      })
    : await prisma.paymentGatewaySettings.create({
        data: { provider: "mercadopago", ...parsed.data },
      });

  return NextResponse.json({
    publicKey: settings.publicKey,
    accessTokenPreview: `${settings.accessToken.slice(0, 8)}••••••••`,
    updatedAt: settings.updatedAt,
  });
}
