import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/api-guards";

// POST /api/upload/video
// Gera uma URL de "upload direto" do Cloudflare Stream: o ADM faz o upload
// do arquivo direto do navegador para essa URL, e o Cloudflare devolve o
// vídeo já pronto em formato HLS (usado depois em Movie.videoUrl / Episode.videoUrl).
// Documentação: https://developers.cloudflare.com/stream/uploading-videos/direct-creator-uploads/
export async function POST() {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = process.env.CLOUDFLARE_STREAM_API_TOKEN;

  if (!accountId || !apiToken) {
    return NextResponse.json(
      {
        error:
          "Cloudflare Stream não configurado. Preencha CLOUDFLARE_ACCOUNT_ID e CLOUDFLARE_STREAM_API_TOKEN no .env.",
      },
      { status: 400 }
    );
  }

  const res = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/stream/direct_upload`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        maxDurationSeconds: 21600, // limite de 6h por vídeo
        requireSignedURLs: false,
      }),
    }
  );

  const data = await res.json();

  if (!data.success) {
    return NextResponse.json(
      { error: "Falha ao gerar URL de upload no Cloudflare Stream." },
      { status: 502 }
    );
  }

  return NextResponse.json({
    uploadUrl: data.result.uploadURL,
    videoId: data.result.uid,
    // depois do upload concluído, o player HLS final fica neste formato:
    playbackUrl: `https://videodelivery.net/${data.result.uid}/manifest/video.m3u8`,
  });
}
