import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const appearanceSchema = z.object({
  logoUrl: z.string().url().optional(),
  faviconUrl: z.string().url().optional(),
  primaryColor: z.string().optional(),
  secondaryColor: z.string().optional(),
  textColor: z.string().optional(),
  backgroundColor: z.string().optional(),
});

// GET /api/appearance — configuração atual (pública, usada pra montar o tema)
export async function GET() {
  const settings = await prisma.appearanceSettings.findFirst();
  return NextResponse.json(settings);
}

// PUT /api/appearance — atualizar aparência (ADM)
export async function PUT(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = appearanceSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const existing = await prisma.appearanceSettings.findFirst();

  const settings = existing
    ? await prisma.appearanceSettings.update({
        where: { id: existing.id },
        data: parsed.data,
      })
    : await prisma.appearanceSettings.create({ data: parsed.data });

  return NextResponse.json(settings);
}
