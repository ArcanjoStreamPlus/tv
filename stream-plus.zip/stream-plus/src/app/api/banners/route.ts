import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const bannerSchema = z.object({
  title: z.string().min(1),
  imageUrl: z.string().url(),
  type: z.string().min(1), // destaque, categoria
  link: z.string().optional(),
  order: z.number().int().optional(),
});

// GET /api/banners — lista banners ativos (usado na home do cliente)
export async function GET() {
  const banners = await prisma.banner.findMany({
    where: { active: true },
    orderBy: { order: "asc" },
  });
  return NextResponse.json(banners);
}

// POST /api/banners — cadastro de banner (ADM)
export async function POST(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = bannerSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const banner = await prisma.banner.create({ data: parsed.data });
  return NextResponse.json(banner, { status: 201 });
}
