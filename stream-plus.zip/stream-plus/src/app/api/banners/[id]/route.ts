import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// PATCH /api/banners/:id — editar banner (ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const banner = await prisma.banner.update({
    where: { id: params.id },
    data: body,
  });

  return NextResponse.json(banner);
}

// DELETE /api/banners/:id — remover banner (ADM)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  await prisma.banner.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
