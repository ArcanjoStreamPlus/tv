import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// PATCH /api/plans/:id — editar plano (ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const plan = await prisma.plan.update({
    where: { id: params.id },
    data: body,
  });

  return NextResponse.json(plan);
}

// DELETE /api/plans/:id — desativa o plano (não apaga, pra não quebrar assinaturas antigas)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const plan = await prisma.plan.update({
    where: { id: params.id },
    data: { active: false },
  });

  return NextResponse.json(plan);
}
