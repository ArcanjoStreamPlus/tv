import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const planSchema = z.object({
  name: z.string().min(1),
  price: z.number().positive(),
  maxDevices: z.number().int().positive(),
  maxSimultaneousStream: z.number().int().positive(),
  quality: z.string().min(1), // HD, Full HD, 4K
  features: z.array(z.string()).optional(), // lista exibida na tela de planos
});

// GET /api/plans — lista de planos (tela "Página de Assinatura" e "Cadastro de Planos")
export async function GET() {
  const plans = await prisma.plan.findMany({
    where: { active: true },
    orderBy: { price: "asc" },
  });
  return NextResponse.json(plans);
}

// POST /api/plans — cadastro de plano (ADM)
export async function POST(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = planSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const plan = await prisma.plan.create({ data: parsed.data });
  return NextResponse.json(plan, { status: 201 });
}
