import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";

// GET /api/subscriptions/me — assinatura ativa do usuário logado
export async function GET() {
  const { session, error } = await requireClient();
  if (error) return error;

  const userId = (session!.user as any).id;

  const subscription = await prisma.subscription.findFirst({
    where: { userId, status: "ATIVA" },
    include: { plan: true, payments: { orderBy: { createdAt: "desc" } } },
    orderBy: { startedAt: "desc" },
  });

  return NextResponse.json(subscription);
}
