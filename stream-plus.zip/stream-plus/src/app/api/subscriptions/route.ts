import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, requireClient } from "@/lib/api-guards";

const subscriptionSchema = z.object({
  userId: z.string(),
  planId: z.string(),
  // duração em dias (padrão 30 - mensal, como nas telas de plano)
  durationDays: z.number().int().positive().optional().default(30),
});

// GET /api/subscriptions — lista assinaturas (tela "Assinaturas" no ADM)
export async function GET(req: NextRequest) {
  const { error } = await requireAdmin("subscriptions:read");
  if (error) return error;

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");

  const subscriptions = await prisma.subscription.findMany({
    where: status ? { status: status as any } : undefined,
    include: { user: true, plan: true },
    orderBy: { startedAt: "desc" },
  });

  return NextResponse.json(subscriptions);
}

// POST /api/subscriptions — cria assinatura (ex: cliente escolhe um plano na tela de assinatura)
export async function POST(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const body = await req.json();
  const parsed = subscriptionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // um cliente só pode assinar em nome dele mesmo, a menos que seja admin
  const currentUserId = (session!.user as any).id;
  const currentUserRole = (session!.user as any).role;
  const isAdmin = currentUserRole !== "CLIENT";

  if (!isAdmin && parsed.data.userId !== currentUserId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 403 });
  }

  const plan = await prisma.plan.findUnique({ where: { id: parsed.data.planId } });
  if (!plan || !plan.active) {
    return NextResponse.json({ error: "Plano inválido" }, { status: 400 });
  }

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + parsed.data.durationDays);

  const subscription = await prisma.subscription.create({
    data: {
      userId: parsed.data.userId,
      planId: parsed.data.planId,
      status: "ATIVA",
      expiresAt,
    },
    include: { plan: true },
  });

  return NextResponse.json(subscription, { status: 201 });
}
