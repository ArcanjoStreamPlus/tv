import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// PATCH /api/subscriptions/:id — atualizar status (ex: cancelar, renovar) — ADM financeiro
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("subscriptions:read");
  if (error) return error;

  const body = await req.json();
  const subscription = await prisma.subscription.update({
    where: { id: params.id },
    data: body,
    include: { plan: true, user: true },
  });

  return NextResponse.json(subscription);
}
