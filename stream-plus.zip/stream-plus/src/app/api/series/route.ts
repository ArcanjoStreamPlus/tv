import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const seriesSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  coverUrl: z.string().url().optional(),
  trailerUrl: z.string().url().optional(),
  genre: z.string().optional(),
  year: z.number().int().optional(),
  classification: z.string().optional(),
  status: z.string().optional(), // "Em andamento" / "Finalizada"
  featured: z.boolean().optional(),
  categoryId: z.string().optional(),
});

// GET /api/series — catálogo de séries (com filtros de gênero/ano/status)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const genre = searchParams.get("genre");
  const year = searchParams.get("year");
  const status = searchParams.get("status");

  const series = await prisma.series.findMany({
    where: {
      ...(genre && { genre }),
      ...(year && { year: Number(year) }),
      ...(status && { status }),
    },
    orderBy: { createdAt: "desc" },
    include: {
      category: true,
      seasons: { include: { episodes: true } },
    },
  });

  return NextResponse.json(series);
}

// POST /api/series — cadastro de série (ADM)
export async function POST(req: NextRequest) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = seriesSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const series = await prisma.series.create({ data: parsed.data });
  return NextResponse.json(series, { status: 201 });
}
