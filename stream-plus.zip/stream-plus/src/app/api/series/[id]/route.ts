import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// GET /api/series/:id — detalhes da série com temporadas e episódios
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const series = await prisma.series.findUnique({
    where: { id: params.id },
    include: {
      category: true,
      seasons: { include: { episodes: true }, orderBy: { seasonNumber: "asc" } },
    },
  });

  if (!series) {
    return NextResponse.json({ error: "Série não encontrada" }, { status: 404 });
  }
  return NextResponse.json(series);
}

// PATCH /api/series/:id — editar série (ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const series = await prisma.series.update({
    where: { id: params.id },
    data: body,
  });

  return NextResponse.json(series);
}

// DELETE /api/series/:id — remover série (ADM)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  await prisma.series.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
