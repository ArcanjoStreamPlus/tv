import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const episodeSchema = z.object({
  episodeNumber: z.number().int(),
  title: z.string().min(1),
  videoUrl: z.string().url(),
  durationMin: z.number().int().optional(),
});

const seasonSchema = z.object({
  seasonNumber: z.number().int(),
  episodes: z.array(episodeSchema).optional().default([]),
});

// POST /api/series/:id/seasons — adiciona uma temporada (com episódios opcionais) a uma série
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("catalog:write");
  if (error) return error;

  const body = await req.json();
  const parsed = seasonSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const season = await prisma.season.create({
    data: {
      seriesId: params.id,
      seasonNumber: parsed.data.seasonNumber,
      episodes: {
        create: parsed.data.episodes,
      },
    },
    include: { episodes: true },
  });

  return NextResponse.json(season, { status: 201 });
}

// GET /api/series/:id/seasons — lista temporadas e episódios de uma série
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const seasons = await prisma.season.findMany({
    where: { seriesId: params.id },
    include: { episodes: { orderBy: { episodeNumber: "asc" } } },
    orderBy: { seasonNumber: "asc" },
  });

  return NextResponse.json(seasons);
}
