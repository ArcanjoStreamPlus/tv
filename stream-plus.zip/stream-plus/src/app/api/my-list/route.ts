import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";

const schema = z.object({
  contentId: z.string(),
  contentType: z.enum(["movie", "series"]),
});

// GET /api/my-list — lista os itens salvos pelo usuário logado
export async function GET() {
  const { session, error } = await requireClient();
  if (error) return error;

  const userId = (session!.user as any).id;

  const items = await prisma.myListItem.findMany({
    where: { userId },
    include: { movie: true, series: true },
    orderBy: { addedAt: "desc" },
  });

  return NextResponse.json(items);
}

// POST /api/my-list — adiciona um filme ou série à lista
export async function POST(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const userId = (session!.user as any).id;
  const { contentId, contentType } = parsed.data;

  const item = await prisma.myListItem.create({
    data: {
      userId,
      movieId: contentType === "movie" ? contentId : undefined,
      seriesId: contentType === "series" ? contentId : undefined,
    },
  });

  return NextResponse.json(item, { status: 201 });
}

// DELETE /api/my-list — remove um item (?contentId=&contentType=)
export async function DELETE(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const { searchParams } = new URL(req.url);
  const contentId = searchParams.get("contentId");
  const contentType = searchParams.get("contentType");
  const userId = (session!.user as any).id;

  if (!contentId || !contentType) {
    return NextResponse.json({ error: "Parâmetros ausentes" }, { status: 400 });
  }

  await prisma.myListItem.deleteMany({
    where: {
      userId,
      ...(contentType === "movie" ? { movieId: contentId } : { seriesId: contentId }),
    },
  });

  return NextResponse.json({ success: true });
}
