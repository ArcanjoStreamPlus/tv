import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient } from "@/lib/api-guards";

// GET /api/notifications — lista as notificações do usuário logado
export async function GET() {
  const { session, error } = await requireClient();
  if (error) return error;

  const userId = (session!.user as any).id;

  const notifications = await prisma.notification.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return NextResponse.json(notifications);
}

// PATCH /api/notifications — marca todas como lidas (?id= marca só uma)
export async function PATCH(req: NextRequest) {
  const { session, error } = await requireClient();
  if (error) return error;

  const userId = (session!.user as any).id;
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  await prisma.notification.updateMany({
    where: { userId, ...(id ? { id } : {}) },
    data: { read: true },
  });

  return NextResponse.json({ success: true });
}
