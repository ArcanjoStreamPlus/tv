import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

const createUserSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6),
  role: z
    .enum([
      "CLIENT",
      "ADMIN_TOTAL",
      "ADMIN_SUPORTE",
      "ADMIN_FINANCEIRO",
      "ADMIN_CONTEUDO",
    ])
    .optional()
    .default("CLIENT"),
});

// GET /api/users — lista usuários (tela "Cadastro de Usuários" / "Administradores")
export async function GET(req: NextRequest) {
  const { error } = await requireAdmin("users:read");
  if (error) return error;

  const { searchParams } = new URL(req.url);
  const role = searchParams.get("role");

  const users = await prisma.user.findMany({
    where: role ? { role: role as any } : undefined,
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      status: true,
      createdAt: true,
      subscriptions: {
        where: { status: "ATIVA" },
        include: { plan: true },
        take: 1,
        orderBy: { startedAt: "desc" },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(users);
}

// POST /api/users — cria usuário (cadastro de cliente na assinatura, ou de admin no painel)
export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = createUserSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // Só admin pode criar outro admin; cadastro de CLIENT é público (tela de assinatura)
  if (parsed.data.role !== "CLIENT") {
    const { error } = await requireAdmin("users:write");
    if (error) return error;
  }

  const existing = await prisma.user.findUnique({
    where: { email: parsed.data.email },
  });
  if (existing) {
    return NextResponse.json({ error: "E-mail já cadastrado" }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(parsed.data.password, 10);

  const user = await prisma.user.create({
    data: {
      name: parsed.data.name,
      email: parsed.data.email,
      passwordHash,
      role: parsed.data.role,
    },
    select: { id: true, name: true, email: true, role: true, status: true },
  });

  return NextResponse.json(user, { status: 201 });
}
