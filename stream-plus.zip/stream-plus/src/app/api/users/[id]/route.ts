import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/api-guards";

// GET /api/users/:id — detalhe do usuário (tela "Página de Perfil do Usuário" no ADM)
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("users:read");
  if (error) return error;

  const user = await prisma.user.findUnique({
    where: { id: params.id },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      status: true,
      createdAt: true,
      subscriptions: { include: { plan: true, payments: true } },
      devices: true,
    },
  });

  if (!user) {
    return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 });
  }
  return NextResponse.json(user);
}

// PATCH /api/users/:id — editar (ex: bloquear/desbloquear, mudar plano de acesso ADM)
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("users:write");
  if (error) return error;

  const body = await req.json();
  // nunca deixa a senha ser alterada por essa rota genérica
  delete body.passwordHash;
  delete body.password;

  const user = await prisma.user.update({
    where: { id: params.id },
    data: body,
    select: { id: true, name: true, email: true, role: true, status: true },
  });

  return NextResponse.json(user);
}

// DELETE /api/users/:id — remove usuário
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { error } = await requireAdmin("users:write");
  if (error) return error;

  await prisma.user.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
