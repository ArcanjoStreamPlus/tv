import { prisma } from "@/lib/prisma";
import CategoryForm from "@/components/admin/CategoryForm";
import DeleteButton from "@/components/admin/DeleteButton";

export default async function AdminCategoriesPage() {
  const categories = await prisma.category.findMany({
    where: { active: true },
    orderBy: { name: "asc" },
  });

  return (
    <div className="p-6 max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold">Categorias</h1>
          <p className="text-sm text-textMuted/60">
            Organize suas categorias de conteúdo
          </p>
        </div>
      </div>

      <CategoryForm />

      <div className="bg-surface rounded-lg overflow-hidden mt-6">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Nome</th>
              <th className="px-4 py-3 font-medium">Tipo</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((category) => (
              <tr key={category.id} className="border-t border-white/5">
                <td className="px-4 py-3">{category.name}</td>
                <td className="px-4 py-3 text-textMuted/60">{category.type}</td>
                <td className="px-4 py-3 text-right">
                  <DeleteButton endpoint={`/api/categories/${category.id}`} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
