"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Category = { id: string; name: string };

export default function NewChannelPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: "",
    coverUrl: "",
    streamUrl: "",
    categoryId: "",
  });

  useEffect(() => {
    fetch("/api/categories?type=CANAL")
      .then((res) => res.json())
      .then(setCategories);
  }, []);

  function updateField<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const res = await fetch("/api/channels", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        categoryId: form.categoryId || undefined,
      }),
    });

    setSaving(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.join(", ") ?? "Erro ao salvar o canal.");
      return;
    }

    router.push("/admin/canais");
    router.refresh();
  }

  return (
    <div className="p-6 max-w-lg">
      <h1 className="text-lg font-semibold mb-1">Adicionar Canal</h1>
      <p className="text-sm text-textMuted/60 mb-6">
        Cadastre a capa e o link de reprodução direto do canal (não é lista
        m3u — é a URL de reprodução já pronta).
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Nome do canal">
          <input
            required
            value={form.name}
            onChange={(e) => updateField("name", e.target.value)}
            className="input"
          />
        </Field>

        <Field label="URL da capa">
          <input
            required
            value={form.coverUrl}
            onChange={(e) => updateField("coverUrl", e.target.value)}
            placeholder="https://..."
            className="input"
          />
        </Field>

        <Field label="Link de reprodução">
          <input
            required
            value={form.streamUrl}
            onChange={(e) => updateField("streamUrl", e.target.value)}
            placeholder="https://.../stream.m3u8"
            className="input"
          />
        </Field>

        <Field label="Categoria">
          <select
            value={form.categoryId}
            onChange={(e) => updateField("categoryId", e.target.value)}
            className="input"
          >
            <option value="">Selecione...</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            {saving ? "Salvando..." : "Salvar"}
          </button>
          <button
            type="button"
            onClick={() => router.push("/admin/canais")}
            className="bg-white/10 hover:bg-white/20 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            Cancelar
          </button>
        </div>
      </form>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.375rem;
          background: #0b0f1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      {children}
    </div>
  );
}
