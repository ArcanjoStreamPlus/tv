import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteButton from "@/components/admin/DeleteButton";

export default async function AdminChannelsPage() {
  const channels = await prisma.channel.findMany({
    orderBy: { name: "asc" },
    include: { category: true },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-lg font-semibold">Canais ao Vivo</h1>
        <Link
          href="/admin/canais/novo"
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
        >
          + Adicionar Canal
        </Link>
      </div>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Nome</th>
              <th className="px-4 py-3 font-medium">Categoria</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {channels.map((channel) => (
              <tr key={channel.id} className="border-t border-white/5">
                <td className="px-4 py-3">{channel.name}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  {channel.category?.name ?? "-"}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      channel.status === "ATIVO"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-white/10 text-textMuted/60"
                    }`}
                  >
                    {channel.status === "ATIVO" ? "Ativo" : "Inativo"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <DeleteButton endpoint={`/api/channels/${channel.id}`} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {channels.length === 0 && (
          <p className="text-textMuted/60 text-sm p-6">
            Nenhum canal cadastrado ainda.
          </p>
        )}
      </div>
    </div>
  );
}
