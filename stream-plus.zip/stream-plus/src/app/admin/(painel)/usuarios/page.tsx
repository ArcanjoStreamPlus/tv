import { prisma } from "@/lib/prisma";
import UserStatusToggle from "@/components/admin/UserStatusToggle";

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    where: { role: "CLIENT" },
    orderBy: { createdAt: "desc" },
    include: {
      subscriptions: {
        where: { status: "ATIVA" },
        include: { plan: true },
        take: 1,
        orderBy: { startedAt: "desc" },
      },
    },
  });

  return (
    <div className="p-6">
      <h1 className="text-lg font-semibold mb-6">Usuários</h1>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Nome</th>
              <th className="px-4 py-3 font-medium">E-mail</th>
              <th className="px-4 py-3 font-medium">Plano</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-t border-white/5">
                <td className="px-4 py-3">{user.name}</td>
                <td className="px-4 py-3 text-textMuted/60">{user.email}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  {user.subscriptions[0]?.plan.name ?? "-"}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      user.status === "ATIVO"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {user.status === "ATIVO" ? "Ativo" : "Bloqueado"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <UserStatusToggle userId={user.id} status={user.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {users.length === 0 && (
          <p className="text-textMuted/60 text-sm p-6">
            Nenhum usuário cadastrado ainda.
          </p>
        )}
      </div>
    </div>
  );
}
