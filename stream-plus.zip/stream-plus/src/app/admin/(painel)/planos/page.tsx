import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteButton from "@/components/admin/DeleteButton";

export default async function AdminPlansPage() {
  const plans = await prisma.plan.findMany({
    where: { active: true },
    orderBy: { price: "asc" },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-lg font-semibold">Planos</h1>
        <Link
          href="/admin/planos/novo"
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
        >
          + Novo Plano
        </Link>
      </div>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Plano</th>
              <th className="px-4 py-3 font-medium">Valor</th>
              <th className="px-4 py-3 font-medium">Qualidade</th>
              <th className="px-4 py-3 font-medium">Dispositivos</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {plans.map((plan) => (
              <tr key={plan.id} className="border-t border-white/5">
                <td className="px-4 py-3">{plan.name}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  R$ {Number(plan.price).toFixed(2)}
                </td>
                <td className="px-4 py-3 text-textMuted/60">{plan.quality}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  {plan.maxDevices} ({plan.maxSimultaneousStream} simultâneos)
                </td>
                <td className="px-4 py-3 text-right">
                  <DeleteButton endpoint={`/api/plans/${plan.id}`} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
