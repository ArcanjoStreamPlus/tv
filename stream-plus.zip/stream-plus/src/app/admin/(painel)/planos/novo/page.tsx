"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewPlanPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: "",
    price: "",
    maxDevices: "1",
    maxSimultaneousStream: "1",
    quality: "HD",
    featuresText: "",
  });

  function updateField<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const res = await fetch("/api/plans", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: form.name,
        price: Number(form.price),
        maxDevices: Number(form.maxDevices),
        maxSimultaneousStream: Number(form.maxSimultaneousStream),
        quality: form.quality,
        features: form.featuresText
          .split("\n")
          .map((f) => f.trim())
          .filter(Boolean),
      }),
    });

    setSaving(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.join(", ") ?? "Erro ao salvar o plano.");
      return;
    }

    router.push("/admin/planos");
    router.refresh();
  }

  return (
    <div className="p-6 max-w-lg">
      <h1 className="text-lg font-semibold mb-6">Novo Plano</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Nome do plano">
          <input
            required
            value={form.name}
            onChange={(e) => updateField("name", e.target.value)}
            placeholder="Premium"
            className="input"
          />
        </Field>

        <Field label="Preço mensal (R$)">
          <input
            required
            type="number"
            step="0.01"
            value={form.price}
            onChange={(e) => updateField("price", e.target.value)}
            className="input"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Dispositivos cadastrados">
            <input
              required
              type="number"
              value={form.maxDevices}
              onChange={(e) => updateField("maxDevices", e.target.value)}
              className="input"
            />
          </Field>
          <Field label="Reproduções simultâneas">
            <input
              required
              type="number"
              value={form.maxSimultaneousStream}
              onChange={(e) => updateField("maxSimultaneousStream", e.target.value)}
              className="input"
            />
          </Field>
        </div>

        <Field label="Qualidade">
          <select
            value={form.quality}
            onChange={(e) => updateField("quality", e.target.value)}
            className="input"
          >
            <option value="HD">HD</option>
            <option value="Full HD">Full HD</option>
            <option value="Full HD / 4K">Full HD / 4K</option>
          </select>
        </Field>

        <Field label="Benefícios (um por linha)">
          <textarea
            rows={5}
            value={form.featuresText}
            onChange={(e) => updateField("featuresText", e.target.value)}
            placeholder={"Canais ao vivo\nFilmes e séries\nQualidade Full HD"}
            className="input"
          />
        </Field>

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            {saving ? "Salvando..." : "Salvar"}
          </button>
          <button
            type="button"
            onClick={() => router.push("/admin/planos")}
            className="bg-white/10 hover:bg-white/20 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            Cancelar
          </button>
        </div>
      </form>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.375rem;
          background: #0b0f1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      {children}
    </div>
  );
}
