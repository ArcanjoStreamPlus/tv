"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewBannerPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "",
    imageUrl: "",
    type: "Destaque",
    link: "",
  });

  function updateField<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const res = await fetch("/api/banners", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        link: form.link || undefined,
      }),
    });

    setSaving(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.join(", ") ?? "Erro ao salvar o banner.");
      return;
    }

    router.push("/admin/banners");
    router.refresh();
  }

  return (
    <div className="p-6 max-w-lg">
      <h1 className="text-lg font-semibold mb-6">Novo Banner</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Título">
          <input
            required
            value={form.title}
            onChange={(e) => updateField("title", e.target.value)}
            className="input"
          />
        </Field>

        <Field label="URL da imagem">
          <input
            required
            value={form.imageUrl}
            onChange={(e) => updateField("imageUrl", e.target.value)}
            placeholder="https://..."
            className="input"
          />
        </Field>

        <Field label="Tipo">
          <select
            value={form.type}
            onChange={(e) => updateField("type", e.target.value)}
            className="input"
          >
            <option>Destaque</option>
            <option>Categoria</option>
          </select>
        </Field>

        <Field label="Link (opcional)">
          <input
            value={form.link}
            onChange={(e) => updateField("link", e.target.value)}
            placeholder="/titulo/movie/..."
            className="input"
          />
        </Field>

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            {saving ? "Salvando..." : "Salvar"}
          </button>
          <button
            type="button"
            onClick={() => router.push("/admin/banners")}
            className="bg-white/10 hover:bg-white/20 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            Cancelar
          </button>
        </div>
      </form>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.375rem;
          background: #0b0f1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      {children}
    </div>
  );
}
