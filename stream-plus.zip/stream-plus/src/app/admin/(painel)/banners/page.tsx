import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteButton from "@/components/admin/DeleteButton";

export default async function AdminBannersPage() {
  const banners = await prisma.banner.findMany({
    where: { active: true },
    orderBy: { order: "asc" },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold">Banners</h1>
          <p className="text-sm text-textMuted/60">
            Gerencie os banners da página inicial
          </p>
        </div>
        <Link
          href="/admin/banners/novo"
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
        >
          + Novo Banner
        </Link>
      </div>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Imagem</th>
              <th className="px-4 py-3 font-medium">Título</th>
              <th className="px-4 py-3 font-medium">Tipo</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {banners.map((banner) => (
              <tr key={banner.id} className="border-t border-white/5">
                <td className="px-4 py-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={banner.imageUrl}
                    alt={banner.title}
                    className="w-16 h-9 object-cover rounded"
                  />
                </td>
                <td className="px-4 py-3">{banner.title}</td>
                <td className="px-4 py-3 text-textMuted/60">{banner.type}</td>
                <td className="px-4 py-3 text-right">
                  <DeleteButton endpoint={`/api/banners/${banner.id}`} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {banners.length === 0 && (
          <p className="text-textMuted/60 text-sm p-6">
            Nenhum banner cadastrado ainda.
          </p>
        )}
      </div>
    </div>
  );
}
