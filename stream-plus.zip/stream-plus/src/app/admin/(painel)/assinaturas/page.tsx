import { prisma } from "@/lib/prisma";

const STATUS_STYLES: Record<string, string> = {
  ATIVA: "bg-green-500/20 text-green-400",
  VENCENDO: "bg-yellow-500/20 text-yellow-400",
  VENCIDA: "bg-red-500/20 text-red-400",
  CANCELADA: "bg-white/10 text-textMuted/60",
  PENDENTE: "bg-blue-500/20 text-blue-400",
};

export default async function AdminSubscriptionsPage() {
  const subscriptions = await prisma.subscription.findMany({
    orderBy: { startedAt: "desc" },
    include: { user: true, plan: true },
  });

  return (
    <div className="p-6">
      <h1 className="text-lg font-semibold mb-6">Assinaturas</h1>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Usuário</th>
              <th className="px-4 py-3 font-medium">Plano</th>
              <th className="px-4 py-3 font-medium">Valor</th>
              <th className="px-4 py-3 font-medium">Vencimento</th>
              <th className="px-4 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {subscriptions.map((sub) => (
              <tr key={sub.id} className="border-t border-white/5">
                <td className="px-4 py-3">
                  <p>{sub.user.name}</p>
                  <p className="text-xs text-textMuted/50">{sub.user.email}</p>
                </td>
                <td className="px-4 py-3 text-textMuted/60">{sub.plan.name}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  R$ {Number(sub.plan.price).toFixed(2)}
                </td>
                <td className="px-4 py-3 text-textMuted/60">
                  {sub.expiresAt.toLocaleDateString("pt-BR")}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${STATUS_STYLES[sub.status]}`}
                  >
                    {sub.status.charAt(0) + sub.status.slice(1).toLowerCase()}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {subscriptions.length === 0 && (
          <p className="text-textMuted/60 text-sm p-6">
            Nenhuma assinatura registrada ainda.
          </p>
        )}
      </div>
    </div>
  );
}
