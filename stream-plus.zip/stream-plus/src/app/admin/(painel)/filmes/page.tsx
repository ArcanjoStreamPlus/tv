import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteButton from "@/components/admin/DeleteButton";

export default async function AdminMoviesPage() {
  const movies = await prisma.movie.findMany({
    orderBy: { createdAt: "desc" },
    include: { category: true },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-lg font-semibold">Filmes</h1>
        <Link
          href="/admin/filmes/novo"
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
        >
          + Novo Filme
        </Link>
      </div>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Título</th>
              <th className="px-4 py-3 font-medium">Categoria</th>
              <th className="px-4 py-3 font-medium">Ano</th>
              <th className="px-4 py-3 font-medium">Destaque</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {movies.map((movie) => (
              <tr key={movie.id} className="border-t border-white/5">
                <td className="px-4 py-3">{movie.title}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  {movie.category?.name ?? "-"}
                </td>
                <td className="px-4 py-3 text-textMuted/60">
                  {movie.year ?? "-"}
                </td>
                <td className="px-4 py-3">
                  {movie.featured ? (
                    <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                      Sim
                    </span>
                  ) : (
                    "-"
                  )}
                </td>
                <td className="px-4 py-3 text-right">
                  <DeleteButton endpoint={`/api/movies/${movie.id}`} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {movies.length === 0 && (
          <p className="text-textMuted/60 text-sm p-6">
            Nenhum filme cadastrado ainda.
          </p>
        )}
      </div>
    </div>
  );
}
