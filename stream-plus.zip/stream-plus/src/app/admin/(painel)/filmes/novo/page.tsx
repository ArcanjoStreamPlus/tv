"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import VideoUploadField from "@/components/admin/VideoUploadField";

type Category = { id: string; name: string };

export default function NewMoviePage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "",
    description: "",
    coverUrl: "",
    trailerUrl: "",
    videoUrl: "",
    genre: "",
    year: "",
    classification: "",
    categoryId: "",
    featured: false,
  });

  useEffect(() => {
    fetch("/api/categories?type=FILME")
      .then((res) => res.json())
      .then(setCategories);
  }, []);

  function updateField<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const res = await fetch("/api/movies", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        year: form.year ? Number(form.year) : undefined,
        coverUrl: form.coverUrl || undefined,
        trailerUrl: form.trailerUrl || undefined,
        categoryId: form.categoryId || undefined,
      }),
    });

    setSaving(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.join(", ") ?? "Erro ao salvar o filme.");
      return;
    }

    router.push("/admin/filmes");
    router.refresh();
  }

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-lg font-semibold mb-6">Adicionar Filme</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Nome do filme">
          <input
            required
            value={form.title}
            onChange={(e) => updateField("title", e.target.value)}
            className="input"
          />
        </Field>

        <Field label="Descrição">
          <textarea
            value={form.description}
            onChange={(e) => updateField("description", e.target.value)}
            rows={3}
            className="input"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="URL da capa">
            <input
              value={form.coverUrl}
              onChange={(e) => updateField("coverUrl", e.target.value)}
              placeholder="https://..."
              className="input"
            />
          </Field>
          <Field label="URL do trailer">
            <input
              value={form.trailerUrl}
              onChange={(e) => updateField("trailerUrl", e.target.value)}
              placeholder="https://..."
              className="input"
            />
          </Field>
        </div>

        <Field label="Vídeo do filme">
          <VideoUploadField
            value={form.videoUrl}
            onChange={(url) => updateField("videoUrl", url)}
          />
        </Field>

        <div className="grid grid-cols-3 gap-4">
          <Field label="Gênero">
            <input
              value={form.genre}
              onChange={(e) => updateField("genre", e.target.value)}
              className="input"
            />
          </Field>
          <Field label="Ano">
            <input
              type="number"
              value={form.year}
              onChange={(e) => updateField("year", e.target.value)}
              className="input"
            />
          </Field>
          <Field label="Classificação">
            <input
              value={form.classification}
              onChange={(e) => updateField("classification", e.target.value)}
              placeholder="16 anos"
              className="input"
            />
          </Field>
        </div>

        <Field label="Categoria">
          <select
            value={form.categoryId}
            onChange={(e) => updateField("categoryId", e.target.value)}
            className="input"
          >
            <option value="">Selecione...</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={form.featured}
            onChange={(e) => updateField("featured", e.target.checked)}
          />
          Destaque na home
        </label>

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            {saving ? "Salvando..." : "Salvar"}
          </button>
          <button
            type="button"
            onClick={() => router.push("/admin/filmes")}
            className="bg-white/10 hover:bg-white/20 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            Cancelar
          </button>
        </div>
      </form>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.375rem;
          background: #0b0f1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      {children}
    </div>
  );
}
