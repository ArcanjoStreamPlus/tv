"use client";

import { useEffect, useState } from "react";

type Settings = {
  publicKey: string;
  accessTokenPreview: string;
  updatedAt: string;
} | null;

export default function PaymentSettingsPage() {
  const [settings, setSettings] = useState<Settings>(null);
  const [publicKey, setPublicKey] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/admin/payment-settings")
      .then((res) => res.json())
      .then((data) => {
        if (data) {
          setSettings(data);
          setPublicKey(data.publicKey);
        }
      });
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    const res = await fetch("/api/admin/payment-settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ publicKey, accessToken }),
    });

    setSaving(false);

    if (res.ok) {
      const data = await res.json();
      setSettings(data);
      setAccessToken("");
      setMessage("Chaves salvas com sucesso.");
    } else {
      setMessage("Erro ao salvar. Confira os dados e tente novamente.");
    }
  }

  return (
    <div className="max-w-lg mx-auto p-6 text-textMuted">
      <h1 className="text-xl font-bold mb-1">Pagamentos — Mercado Pago</h1>
      <p className="text-sm text-textMuted/70 mb-6">
        Cadastre as credenciais da sua conta Mercado Pago. Você encontra a
        Public Key e o Access Token em: Seu negócio → Configurações →
        Credenciais, no painel do Mercado Pago.
      </p>

      {settings && (
        <div className="mb-6 bg-surface rounded-md p-4 text-sm">
          <p>
            <span className="text-textMuted/60">Public Key atual:</span>{" "}
            {settings.publicKey}
          </p>
          <p>
            <span className="text-textMuted/60">Access Token atual:</span>{" "}
            {settings.accessTokenPreview}
          </p>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-4">
        <div>
          <label className="block text-sm mb-1">Public Key</label>
          <input
            type="text"
            required
            value={publicKey}
            onChange={(e) => setPublicKey(e.target.value)}
            placeholder="APP_USR-xxxxxxxx-xxxxxx..."
            className="w-full rounded-md bg-background border border-white/10 px-3 py-2"
          />
        </div>

        <div>
          <label className="block text-sm mb-1">Access Token</label>
          <input
            type="password"
            required
            value={accessToken}
            onChange={(e) => setAccessToken(e.target.value)}
            placeholder="APP_USR-xxxxxxxx-xxxxxx..."
            className="w-full rounded-md bg-background border border-white/10 px-3 py-2"
          />
          <p className="text-xs text-textMuted/50 mt-1">
            Essa chave é privada — nunca é exibida de volta na tela, só uma
            prévia depois de salva.
          </p>
        </div>

        {message && <p className="text-sm text-secondary">{message}</p>}

        <button
          type="submit"
          disabled={saving}
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 font-semibold"
        >
          {saving ? "Salvando..." : "Salvar Alterações"}
        </button>
      </form>
    </div>
  );
}
