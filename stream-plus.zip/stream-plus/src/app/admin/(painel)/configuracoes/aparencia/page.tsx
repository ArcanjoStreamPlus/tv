"use client";

import { useEffect, useState } from "react";

type Appearance = {
  logoUrl: string | null;
  faviconUrl: string | null;
  primaryColor: string;
  secondaryColor: string;
  textColor: string;
  backgroundColor: string;
};

const DEFAULTS: Appearance = {
  logoUrl: "",
  faviconUrl: "",
  primaryColor: "#6C63FF",
  secondaryColor: "#00D4FF",
  textColor: "#E5E7EB",
  backgroundColor: "#0B0F1A",
};

export default function AppearanceSettingsPage() {
  const [form, setForm] = useState<Appearance>(DEFAULTS);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/appearance")
      .then((res) => res.json())
      .then((data) => {
        if (data) setForm({ ...DEFAULTS, ...data });
      });
  }, []);

  function updateField<K extends keyof Appearance>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    const res = await fetch("/api/appearance", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    setSaving(false);
    setMessage(res.ok ? "Alterações salvas com sucesso." : "Erro ao salvar.");
  }

  return (
    <div className="p-6 max-w-3xl">
      <h1 className="text-lg font-semibold mb-1">Configurações de Aparência</h1>
      <p className="text-sm text-textMuted/60 mb-6">
        Personalize a aparência da sua plataforma
      </p>

      <div className="grid sm:grid-cols-2 gap-6">
        <form onSubmit={handleSave} className="space-y-4">
          <Field label="URL do logo">
            <input
              value={form.logoUrl ?? ""}
              onChange={(e) => updateField("logoUrl", e.target.value)}
              placeholder="https://..."
              className="input"
            />
          </Field>

          <Field label="URL do favicon">
            <input
              value={form.faviconUrl ?? ""}
              onChange={(e) => updateField("faviconUrl", e.target.value)}
              placeholder="https://..."
              className="input"
            />
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <ColorField
              label="Cor Primária"
              value={form.primaryColor}
              onChange={(v) => updateField("primaryColor", v)}
            />
            <ColorField
              label="Cor Secundária"
              value={form.secondaryColor}
              onChange={(v) => updateField("secondaryColor", v)}
            />
            <ColorField
              label="Cor do Texto"
              value={form.textColor}
              onChange={(v) => updateField("textColor", v)}
            />
            <ColorField
              label="Cor de Fundo"
              value={form.backgroundColor}
              onChange={(v) => updateField("backgroundColor", v)}
            />
          </div>

          {message && <p className="text-sm text-secondary">{message}</p>}

          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            {saving ? "Salvando..." : "Salvar Alterações"}
          </button>
        </form>

        <div>
          <p className="text-xs text-textMuted/50 mb-2 uppercase tracking-wide">
            Pré-visualização
          </p>
          <div
            className="rounded-lg p-6 border border-white/10"
            style={{ background: form.backgroundColor, color: form.textColor }}
          >
            <p className="font-bold mb-1" style={{ color: form.primaryColor }}>
              StreamPlus
            </p>
            <p className="text-sm mb-4">Sua diversão, em um só lugar</p>
            <div className="flex gap-2">
              <span
                className="px-3 py-1.5 rounded-md text-xs font-semibold"
                style={{ background: form.primaryColor, color: "#fff" }}
              >
                Botão primário
              </span>
              <span
                className="px-3 py-1.5 rounded-md text-xs font-semibold"
                style={{ background: form.secondaryColor, color: "#000" }}
              >
                Botão secundário
              </span>
            </div>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.375rem;
          background: #0b0f1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      {children}
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-9 h-9 rounded border border-white/10 bg-transparent"
        />
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="input"
        />
      </div>
    </div>
  );
}
