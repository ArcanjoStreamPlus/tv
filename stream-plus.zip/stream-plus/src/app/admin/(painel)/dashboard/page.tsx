import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const [
    activeUsers,
    activeSubscriptions,
    totalMovies,
    totalSeries,
    totalChannels,
    totalAnimes,
    payments,
  ] = await Promise.all([
    prisma.user.count({ where: { role: "CLIENT", status: "ATIVO" } }),
    prisma.subscription.count({ where: { status: "ATIVA" } }),
    prisma.movie.count(),
    prisma.series.count(),
    prisma.channel.count(),
    prisma.category.count({ where: { type: "ANIME" } }),
    prisma.payment.findMany({
      where: {
        status: "APROVADO",
        paidAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
  ]);

  const revenueLast7Days = payments.reduce(
    (sum, p) => sum + Number(p.amount),
    0
  );

  const stats = [
    { label: "Usuários Ativos", value: activeUsers },
    {
      label: "Receita do Mês",
      value: `R$ ${revenueLast7Days.toFixed(2)}`,
    },
    { label: "Conteúdos Cadastrados", value: totalMovies + totalSeries },
    { label: "Canais ao Vivo", value: totalChannels },
    { label: "Filmes", value: totalMovies },
    { label: "Séries", value: totalSeries },
  ];

  return (
    <div className="p-6">
      <h1 className="text-lg font-semibold mb-6">Dashboard</h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-surface rounded-lg p-5">
            <p className="text-xs text-textMuted/50 mb-1">{stat.label}</p>
            <p className="text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-surface rounded-lg p-5">
        <p className="text-sm font-medium mb-1">Assinaturas ativas</p>
        <p className="text-2xl font-bold">{activeSubscriptions}</p>
        <p className="text-xs text-textMuted/50 mt-1">
          Receita aprovada nos últimos 7 dias: R$ {revenueLast7Days.toFixed(2)}
        </p>
      </div>
    </div>
  );
}
