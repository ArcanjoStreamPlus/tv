import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteButton from "@/components/admin/DeleteButton";

export default async function AdminSeriesPage() {
  const seriesList = await prisma.series.findMany({
    orderBy: { createdAt: "desc" },
    include: { category: true, seasons: { include: { episodes: true } } },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-lg font-semibold">Séries</h1>
        <Link
          href="/admin/series/novo"
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
        >
          + Nova Série
        </Link>
      </div>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Título</th>
              <th className="px-4 py-3 font-medium">Categoria</th>
              <th className="px-4 py-3 font-medium">Temporadas</th>
              <th className="px-4 py-3 font-medium">Episódios</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {seriesList.map((series) => {
              const episodeCount = series.seasons.reduce(
                (sum, s) => sum + s.episodes.length,
                0
              );
              return (
                <tr key={series.id} className="border-t border-white/5">
                  <td className="px-4 py-3">
                    <Link
                      href={`/admin/series/${series.id}`}
                      className="hover:text-primary transition"
                    >
                      {series.title}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-textMuted/60">
                    {series.category?.name ?? "-"}
                  </td>
                  <td className="px-4 py-3 text-textMuted/60">
                    {series.seasons.length}
                  </td>
                  <td className="px-4 py-3 text-textMuted/60">
                    {episodeCount}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <DeleteButton endpoint={`/api/series/${series.id}`} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {seriesList.length === 0 && (
          <p className="text-textMuted/60 text-sm p-6">
            Nenhuma série cadastrada ainda.
          </p>
        )}
      </div>
    </div>
  );
}
