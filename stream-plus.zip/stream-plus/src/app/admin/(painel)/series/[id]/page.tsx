import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import SeasonManager from "@/components/admin/SeasonManager";

export default async function SeriesEpisodesPage({
  params,
}: {
  params: { id: string };
}) {
  const series = await prisma.series.findUnique({
    where: { id: params.id },
    include: {
      seasons: { include: { episodes: true }, orderBy: { seasonNumber: "asc" } },
    },
  });

  if (!series) return notFound();

  return (
    <div className="p-6 max-w-3xl">
      <h1 className="text-lg font-semibold mb-1">{series.title}</h1>
      <p className="text-sm text-textMuted/60 mb-6">
        Gerencie as temporadas e episódios desta série.
      </p>

      <SeasonManager
        seriesId={series.id}
        initialSeasons={series.seasons.map((s) => ({
          id: s.id,
          seasonNumber: s.seasonNumber,
          episodes: s.episodes.map((e) => ({
            id: e.id,
            episodeNumber: e.episodeNumber,
            title: e.title,
            videoUrl: e.videoUrl,
            durationMin: e.durationMin,
          })),
        }))}
      />
    </div>
  );
}
