"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const ROLES = [
  { value: "ADMIN_TOTAL", label: "Administrador (Total)" },
  { value: "ADMIN_SUPORTE", label: "Suporte" },
  { value: "ADMIN_FINANCEIRO", label: "Financeiro" },
  { value: "ADMIN_CONTEUDO", label: "Conteúdo" },
];

export default function NewAdministratorPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "ADMIN_SUPORTE",
  });

  function updateField<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const res = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    setSaving(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.join(", ") ?? data.error ?? "Erro ao criar administrador.");
      return;
    }

    router.push("/admin/administradores");
    router.refresh();
  }

  return (
    <div className="p-6 max-w-lg">
      <h1 className="text-lg font-semibold mb-6">Novo Administrador</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Nome">
          <input
            required
            value={form.name}
            onChange={(e) => updateField("name", e.target.value)}
            className="input"
          />
        </Field>

        <Field label="E-mail">
          <input
            required
            type="email"
            value={form.email}
            onChange={(e) => updateField("email", e.target.value)}
            className="input"
          />
        </Field>

        <Field label="Senha provisória">
          <input
            required
            type="password"
            minLength={6}
            value={form.password}
            onChange={(e) => updateField("password", e.target.value)}
            className="input"
          />
        </Field>

        <Field label="Nível de acesso">
          <select
            value={form.role}
            onChange={(e) => updateField("role", e.target.value)}
            className="input"
          >
            {ROLES.map((r) => (
              <option key={r.value} value={r.value}>
                {r.label}
              </option>
            ))}
          </select>
        </Field>

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            {saving ? "Salvando..." : "Salvar"}
          </button>
          <button
            type="button"
            onClick={() => router.push("/admin/administradores")}
            className="bg-white/10 hover:bg-white/20 transition rounded-md px-5 py-2 text-sm font-semibold"
          >
            Cancelar
          </button>
        </div>
      </form>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.375rem;
          background: #0b0f1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm mb-1 text-textMuted/80">{label}</label>
      {children}
    </div>
  );
}
