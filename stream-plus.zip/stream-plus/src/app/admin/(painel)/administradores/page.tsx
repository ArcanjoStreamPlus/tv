import Link from "next/link";
import { prisma } from "@/lib/prisma";
import UserStatusToggle from "@/components/admin/UserStatusToggle";

const ROLE_LABEL: Record<string, string> = {
  ADMIN_TOTAL: "Administrador (Total)",
  ADMIN_SUPORTE: "Suporte",
  ADMIN_FINANCEIRO: "Financeiro",
  ADMIN_CONTEUDO: "Conteúdo",
};

export default async function AdminAdministratorsPage() {
  const admins = await prisma.user.findMany({
    where: {
      role: { in: ["ADMIN_TOTAL", "ADMIN_SUPORTE", "ADMIN_FINANCEIRO", "ADMIN_CONTEUDO"] },
    },
    orderBy: { createdAt: "asc" },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold">Administradores</h1>
          <p className="text-sm text-textMuted/60">
            Gerencie os acessos dos administradores
          </p>
        </div>
        <Link
          href="/admin/administradores/novo"
          className="bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
        >
          + Novo Administrador
        </Link>
      </div>

      <div className="bg-surface rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-textMuted/60 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Nome</th>
              <th className="px-4 py-3 font-medium">E-mail</th>
              <th className="px-4 py-3 font-medium">Nível</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {admins.map((admin) => (
              <tr key={admin.id} className="border-t border-white/5">
                <td className="px-4 py-3">{admin.name}</td>
                <td className="px-4 py-3 text-textMuted/60">{admin.email}</td>
                <td className="px-4 py-3 text-textMuted/60">
                  {ROLE_LABEL[admin.role]}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      admin.status === "ATIVO"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {admin.status === "ATIVO" ? "Ativo" : "Bloqueado"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <UserStatusToggle userId={admin.id} status={admin.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
