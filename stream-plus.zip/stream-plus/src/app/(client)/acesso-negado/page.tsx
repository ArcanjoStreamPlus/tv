import Link from "next/link";
import { Lock } from "lucide-react";

export default function AccessDeniedPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-white px-4">
      <div className="w-full max-w-sm bg-surface rounded-xl p-8 text-center">
        <div className="w-14 h-14 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto mb-4">
          <Lock size={24} />
        </div>

        <h1 className="text-xl font-bold mb-2">Acesso Negado</h1>
        <p className="text-sm text-textMuted/60 mb-6">
          Sua assinatura expirou ou você não tem permissão para acessar este
          conteúdo.
        </p>

        <div className="flex flex-col gap-3">
          <Link
            href="/perfil/assinatura"
            className="bg-primary hover:opacity-90 transition rounded-md py-2.5 font-semibold"
          >
            Ver planos
          </Link>
          <Link
            href="/"
            className="bg-white/10 hover:bg-white/20 transition rounded-md py-2.5 font-semibold"
          >
            Voltar para o início
          </Link>
        </div>
      </div>
    </div>
  );
}
