import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import MarkAllReadButton from "@/components/MarkAllReadButton";
import { MessageCircle, Mail, Phone } from "lucide-react";

const TYPE_ICON_COLOR: Record<string, string> = {
  PAGAMENTO: "bg-green-500/20 text-green-400",
  CONTEUDO: "bg-blue-500/20 text-blue-400",
  ASSINATURA: "bg-primary/20 text-primary",
  DISPOSITIVO: "bg-red-500/20 text-red-400",
  SISTEMA: "bg-white/10 text-textMuted/60",
};

function timeAgo(date: Date) {
  const diffMs = Date.now() - date.getTime();
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  if (hours < 1) return "Agora há pouco";
  if (hours < 24) return `Há ${hours}h`;
  const days = Math.floor(hours / 24);
  return days === 1 ? "Ontem" : `Há ${days} dias`;
}

export default async function NotificationsPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;

  const notifications = await prisma.notification.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 grid sm:grid-cols-3 gap-6">
        <div className="sm:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-lg font-semibold">Notificações</h1>
            {notifications.some((n) => !n.read) && <MarkAllReadButton />}
          </div>

          <ul className="space-y-2">
            {notifications.map((n) => (
              <li
                key={n.id}
                className={`rounded-md p-4 ${
                  n.read ? "bg-surface" : "bg-surface ring-1 ring-primary/40"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span
                      className={`inline-block text-[10px] uppercase tracking-wide px-2 py-0.5 rounded-full mb-1.5 ${TYPE_ICON_COLOR[n.type]}`}
                    >
                      {n.type}
                    </span>
                    <p className="text-sm font-medium">{n.title}</p>
                    <p className="text-sm text-textMuted/60">{n.message}</p>
                  </div>
                  <span className="text-xs text-textMuted/40 whitespace-nowrap">
                    {timeAgo(n.createdAt)}
                  </span>
                </div>
              </li>
            ))}

            {notifications.length === 0 && (
              <p className="text-textMuted/60 text-sm">
                Você não tem notificações no momento.
              </p>
            )}
          </ul>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-4">Suporte</h2>
          <div className="bg-surface rounded-lg p-5">
            <p className="text-sm text-textMuted/60 mb-4">
              Precisa de ajuda? Nossa equipe está pronta para te atender.
            </p>
            <div className="space-y-2">
              <a
                href="https://wa.me/5500000000000"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-green-600/80 hover:bg-green-600 transition rounded-md px-4 py-2 text-sm font-medium"
              >
                <MessageCircle size={16} />
                WhatsApp
              </a>
              <a
                href="mailto:suporte@streamplus.com"
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition rounded-md px-4 py-2 text-sm font-medium"
              >
                <Mail size={16} />
                E-mail
              </a>
              <button className="flex items-center gap-2 w-full bg-white/10 hover:bg-white/20 transition rounded-md px-4 py-2 text-sm font-medium">
                <Phone size={16} />
                Chat online
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

