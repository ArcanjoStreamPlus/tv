import { notFound, redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import LiveChannelPlayer from "@/components/LiveChannelPlayer";
import VodPlayer from "@/components/VodPlayer";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";

type WatchPageProps = {
  params: { type: "movie" | "episode" | "channel"; id: string };
};

export default async function WatchPage({ params }: WatchPageProps) {
  const { type, id } = params;

  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;
  const activeSubscription = await prisma.subscription.findFirst({
    where: { userId, status: "ATIVA" },
  });

  if (!activeSubscription) {
    redirect("/acesso-negado");
  }

  if (type === "channel") {
    const channel = await prisma.channel.findUnique({ where: { id } });
    if (!channel) return notFound();

    return (
      <PlayerShell title={channel.name} backHref="/canais">
        <LiveChannelPlayer streamUrl={channel.streamUrl} channelName={channel.name} />
      </PlayerShell>
    );
  }

  if (type === "movie") {
    const movie = await prisma.movie.findUnique({ where: { id } });
    if (!movie) return notFound();

    return (
      <PlayerShell title={movie.title} backHref={`/titulo/movie/${movie.id}`}>
        <VodPlayer videoUrl={movie.videoUrl} contentId={movie.id} contentType="movie" />
      </PlayerShell>
    );
  }

  // episode
  const episode = await prisma.episode.findUnique({
    where: { id },
    include: { season: { include: { series: true } } },
  });
  if (!episode) return notFound();

  return (
    <PlayerShell
      title={`${episode.season.series.title} · ${episode.title}`}
      backHref={`/titulo/series/${episode.season.series.id}`}
    >
      <VodPlayer
        videoUrl={episode.videoUrl}
        contentId={episode.id}
        contentType="episode"
      />
    </PlayerShell>
  );
}

function PlayerShell({
  title,
  backHref,
  children,
}: {
  title: string;
  backHref: string;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex items-center gap-3 px-4 sm:px-6 py-4">
        <Link href={backHref} aria-label="Voltar" className="text-textMuted/70 hover:text-white">
          <ChevronLeft size={20} />
        </Link>
        <h1 className="text-sm font-medium truncate">{title}</h1>
      </div>

      <div className="flex-1 flex items-center justify-center px-2 sm:px-6 pb-6">
        <div className="w-full max-w-5xl">{children}</div>
      </div>
    </div>
  );
}
