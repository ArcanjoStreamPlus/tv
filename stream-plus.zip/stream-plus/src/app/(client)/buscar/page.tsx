import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import ContentCard from "@/components/ContentCard";
import Link from "next/link";

type SearchPageProps = {
  searchParams: { q?: string };
};

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const q = searchParams.q?.trim() ?? "";

  const [movies, series, channels] =
    q.length >= 2
      ? await Promise.all([
          prisma.movie.findMany({
            where: { title: { contains: q, mode: "insensitive" } },
          }),
          prisma.series.findMany({
            where: { title: { contains: q, mode: "insensitive" } },
          }),
          prisma.channel.findMany({
            where: { name: { contains: q, mode: "insensitive" }, status: "ATIVO" },
          }),
        ])
      : [[], [], []];

  const hasResults = movies.length + series.length + channels.length > 0;

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-6">
          {q ? (
            <>
              Resultados para <span className="text-primary">"{q}"</span>
            </>
          ) : (
            "Buscar"
          )}
        </h1>

        {!hasResults && q.length >= 2 && (
          <p className="text-textMuted/60">Nenhum resultado encontrado.</p>
        )}

        {movies.length > 0 && (
          <section className="mb-8">
            <h2 className="text-sm font-medium text-textMuted/60 mb-3">Filmes</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
              {movies.map((m) => (
                <ContentCard key={m.id} id={m.id} title={m.title} coverUrl={m.coverUrl} type="movie" />
              ))}
            </div>
          </section>
        )}

        {series.length > 0 && (
          <section className="mb-8">
            <h2 className="text-sm font-medium text-textMuted/60 mb-3">Séries</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
              {series.map((s) => (
                <ContentCard key={s.id} id={s.id} title={s.title} coverUrl={s.coverUrl} type="series" />
              ))}
            </div>
          </section>
        )}

        {channels.length > 0 && (
          <section>
            <h2 className="text-sm font-medium text-textMuted/60 mb-3">Canais</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {channels.map((c) => (
                <Link
                  key={c.id}
                  href={`/assistir/channel/${c.id}`}
                  className="bg-surface rounded-lg p-3 hover:ring-2 hover:ring-primary/60 transition text-sm"
                >
                  {c.name}
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
