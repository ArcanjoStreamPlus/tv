"use client";

import { useState } from "react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    await fetch("/api/auth/esqueci-senha", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    setLoading(false);
    setSent(true);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-textMuted px-4">
      <div className="w-full max-w-sm bg-surface rounded-xl p-8">
        <h1 className="text-xl font-bold mb-1">Recuperar sua senha</h1>

        {sent ? (
          <p className="text-sm text-textMuted/70 mt-4">
            Se esse e-mail estiver cadastrado, você vai receber um link para
            redefinir sua senha. Confira também a caixa de spam.
          </p>
        ) : (
          <>
            <p className="text-sm text-textMuted/70 mb-6">
              Digite o e-mail cadastrado na sua conta e enviaremos um link de
              verificação.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm mb-1">E-mail</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  className="w-full rounded-md bg-background border border-white/10 px-3 py-2"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:opacity-90 transition rounded-md py-2 font-semibold"
              >
                {loading ? "Enviando..." : "Enviar link"}
              </button>
            </form>
          </>
        )}

        <p className="text-sm text-center mt-4">
          <a href="/login" className="text-secondary">
            Voltar para o login
          </a>
        </p>
      </div>
    </div>
  );
}
