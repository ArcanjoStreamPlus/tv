import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import Link from "next/link";

export default async function ChannelsPage() {
  const channels = await prisma.channel.findMany({
    where: { status: "ATIVO" },
    orderBy: { name: "asc" },
    include: { category: true },
  });

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-6">Canais ao Vivo</h1>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {channels.map((channel) => (
            <Link
              key={channel.id}
              href={`/assistir/channel/${channel.id}`}
              className="group bg-surface rounded-lg overflow-hidden hover:ring-2 hover:ring-primary/60 transition"
            >
              <div className="aspect-video relative bg-black/40">
                {channel.coverUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={channel.coverUrl}
                    alt={channel.name}
                    className="w-full h-full object-contain p-6"
                  />
                )}
                <span className="absolute top-2 right-2 bg-red-600 text-[10px] font-bold px-2 py-0.5 rounded">
                  AO VIVO
                </span>
              </div>
              <div className="p-3">
                <p className="font-medium text-sm">{channel.name}</p>
                {channel.category && (
                  <p className="text-xs text-textMuted/50">
                    {channel.category.name}
                  </p>
                )}
              </div>
            </Link>
          ))}
        </div>

        {channels.length === 0 && (
          <p className="text-textMuted/60">
            Nenhum canal cadastrado ainda.
          </p>
        )}
      </div>
    </div>
  );
}
