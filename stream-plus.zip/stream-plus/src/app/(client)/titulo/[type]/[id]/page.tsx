import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import Link from "next/link";

type DetailPageProps = {
  params: { type: "movie" | "series"; id: string };
};

export default async function ContentDetailPage({ params }: DetailPageProps) {
  const { type, id } = params;

  const content =
    type === "movie"
      ? await prisma.movie.findUnique({ where: { id } })
      : await prisma.series.findUnique({
          where: { id },
          include: { seasons: { include: { episodes: true }, orderBy: { seasonNumber: "asc" } } },
        });

  if (!content) return notFound();

  const isSeries = type === "series";
  const series = isSeries ? (content as any) : null;

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="relative h-[45vh] min-h-[300px]">
        {content.coverUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={content.coverUrl}
            alt={content.title}
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 -mt-20 relative z-10">
        <h1 className="text-3xl font-bold mb-2">{content.title}</h1>

        <p className="text-sm text-textMuted/60 mb-4">
          {[
            content.genre,
            "year" in content ? content.year : null,
            content.classification,
            "rating" in content && content.rating
              ? `★ ${content.rating}`
              : null,
          ]
            .filter(Boolean)
            .join(" · ")}
        </p>

        {content.description && (
          <p className="text-textMuted/80 mb-6 max-w-2xl">
            {content.description}
          </p>
        )}

        <div className="flex gap-3 mb-10">
          <Link
            href={
              isSeries && series.seasons?.[0]?.episodes?.[0]
                ? `/assistir/episode/${series.seasons[0].episodes[0].id}`
                : `/assistir/movie/${id}`
            }
            className="bg-primary hover:opacity-90 transition rounded-md px-6 py-2.5 font-semibold"
          >
            ▶ Assistir
          </Link>
          <button className="bg-white/10 hover:bg-white/20 transition rounded-md px-6 py-2.5 font-semibold">
            + Minha Lista
          </button>
        </div>

        {isSeries && series.seasons?.length > 0 && (
          <section className="pb-16">
            <h2 className="text-lg font-semibold mb-4">Temporadas</h2>
            {series.seasons.map((season: any) => (
              <div key={season.id} className="mb-6">
                <h3 className="text-sm font-medium text-textMuted/70 mb-2">
                  Temporada {season.seasonNumber}
                </h3>
                <ul className="space-y-2">
                  {season.episodes.map((ep: any) => (
                    <li key={ep.id}>
                      <Link
                        href={`/assistir/episode/${ep.id}`}
                        className="flex items-center justify-between bg-surface rounded-md px-4 py-3 hover:bg-white/5 transition"
                      >
                        <span className="text-sm">
                          {ep.episodeNumber}. {ep.title}
                        </span>
                        {ep.durationMin && (
                          <span className="text-xs text-textMuted/50">
                            {ep.durationMin} min
                          </span>
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </section>
        )}
      </div>
    </div>
  );
}
