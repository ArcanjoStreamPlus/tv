import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import ContentCard from "@/components/ContentCard";

export default async function MyListPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;

  const items = await prisma.myListItem.findMany({
    where: { userId },
    include: { movie: true, series: true },
    orderBy: { addedAt: "desc" },
  });

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-1">Minha Lista</h1>
        <p className="text-sm text-textMuted/60 mb-6">
          Seus conteúdos favoritos em um só lugar
        </p>

        {items.length === 0 ? (
          <p className="text-textMuted/60">
            Você ainda não adicionou nada à sua lista.
          </p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {items.map((item) => {
              const content = item.movie ?? item.series;
              if (!content) return null;
              return (
                <ContentCard
                  key={item.id}
                  id={content.id}
                  title={content.title}
                  coverUrl={content.coverUrl}
                  type={item.movieId ? "movie" : "series"}
                />
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
