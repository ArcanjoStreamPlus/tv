import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import DeviceList from "@/components/DeviceList";

export default async function DevicesPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;

  const [devices, activeSubscription] = await Promise.all([
    prisma.device.findMany({
      where: { userId },
      orderBy: { lastActive: "desc" },
    }),
    prisma.subscription.findFirst({
      where: { userId, status: "ATIVA" },
      include: { plan: true },
    }),
  ]);

  const maxDevices = activeSubscription?.plan.maxDevices ?? 1;
  const maxSimultaneous = activeSubscription?.plan.maxSimultaneousStream ?? 1;

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-1">Gerenciar Dispositivos</h1>
        <p className="text-sm text-textMuted/60 mb-6">
          Dispositivos cadastrados: {devices.length}/{maxDevices} ·
          Reproduções simultâneas permitidas: {maxSimultaneous}
        </p>

        {devices.length === 0 ? (
          <p className="text-textMuted/60">Nenhum dispositivo cadastrado.</p>
        ) : (
          <DeviceList
            devices={devices.map((d) => ({
              ...d,
              lastActive: d.lastActive.toISOString(),
            }))}
          />
        )}
      </div>
    </div>
  );
}
