import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";

const STATUS_STYLES: Record<string, string> = {
  APROVADO: "bg-green-500/20 text-green-400",
  PENDENTE: "bg-yellow-500/20 text-yellow-400",
  RECUSADO: "bg-red-500/20 text-red-400",
};

const STATUS_LABEL: Record<string, string> = {
  APROVADO: "Pago",
  PENDENTE: "Pendente",
  RECUSADO: "Falhou",
};

export default async function PaymentsPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;

  const payments = await prisma.payment.findMany({
    where: { subscription: { userId } },
    include: { subscription: { include: { plan: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-6">Histórico de Pagamentos</h1>

        <div className="bg-surface rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-white/5 text-textMuted/60 text-left">
              <tr>
                <th className="px-4 py-3 font-medium">Data</th>
                <th className="px-4 py-3 font-medium">Plano</th>
                <th className="px-4 py-3 font-medium">Valor</th>
                <th className="px-4 py-3 font-medium">Método</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((payment) => (
                <tr key={payment.id} className="border-t border-white/5">
                  <td className="px-4 py-3 text-textMuted/60">
                    {payment.createdAt.toLocaleDateString("pt-BR")}
                  </td>
                  <td className="px-4 py-3">{payment.subscription.plan.name}</td>
                  <td className="px-4 py-3 text-textMuted/60">
                    R$ {Number(payment.amount).toFixed(2)}
                  </td>
                  <td className="px-4 py-3 text-textMuted/60">
                    {payment.method === "PIX" ? "Pix" : "Cartão"}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${STATUS_STYLES[payment.status]}`}
                    >
                      {STATUS_LABEL[payment.status]}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {payments.length === 0 && (
            <p className="text-textMuted/60 text-sm p-6">
              Nenhum pagamento registrado ainda.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
