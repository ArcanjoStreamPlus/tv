import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";

export default async function ProfilePage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;

  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      subscriptions: {
        where: { status: "ATIVA" },
        include: { plan: true },
        orderBy: { startedAt: "desc" },
        take: 1,
      },
      devices: true,
    },
  });

  if (!user) redirect("/login");

  const activeSubscription = user.subscriptions[0];

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-6">Meu Perfil</h1>

        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-full bg-surface flex items-center justify-center text-xl font-bold">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="font-semibold">{user.name}</p>
            <p className="text-sm text-textMuted/60">{user.email}</p>
            {activeSubscription && (
              <span className="inline-block mt-1 text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                Plano {activeSubscription.plan.name}
              </span>
            )}
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="bg-surface rounded-lg p-5">
            <h2 className="font-medium mb-1">Informações da Conta</h2>
            <p className="text-sm text-textMuted/60 mb-4">
              Nome, e-mail e senha de acesso
            </p>
            <dl className="text-sm space-y-1 mb-4">
              <div className="flex justify-between">
                <dt className="text-textMuted/50">Nome</dt>
                <dd>{user.name}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-textMuted/50">E-mail</dt>
                <dd>{user.email}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-textMuted/50">Data de cadastro</dt>
                <dd>{user.createdAt.toLocaleDateString("pt-BR")}</dd>
              </div>
            </dl>
          </div>

          <div className="bg-surface rounded-lg p-5">
            <h2 className="font-medium mb-1">Plano Atual</h2>
            {activeSubscription ? (
              <>
                <p className="text-sm text-textMuted/60 mb-4">
                  {activeSubscription.plan.name} · R${" "}
                  {Number(activeSubscription.plan.price).toFixed(2)}/mês
                </p>
                <p className="text-xs text-textMuted/50 mb-4">
                  Vencimento:{" "}
                  {activeSubscription.expiresAt.toLocaleDateString("pt-BR")}
                </p>
              </>
            ) : (
              <p className="text-sm text-textMuted/60 mb-4">
                Você ainda não tem uma assinatura ativa.
              </p>
            )}
            <Link
              href="/perfil/assinatura"
              className="inline-block bg-primary hover:opacity-90 transition rounded-md px-4 py-2 text-sm font-semibold"
            >
              Gerenciar assinatura
            </Link>
          </div>

          <Link
            href="/perfil/pagamentos"
            className="bg-surface rounded-lg p-5 hover:bg-white/5 transition"
          >
            <h2 className="font-medium mb-1">Histórico de Pagamentos</h2>
            <p className="text-sm text-textMuted/60">
              Veja suas faturas e comprovantes
            </p>
          </Link>

          <Link
            href="/perfil/dispositivos"
            className="bg-surface rounded-lg p-5 hover:bg-white/5 transition"
          >
            <h2 className="font-medium mb-1">Dispositivos</h2>
            <p className="text-sm text-textMuted/60">
              {user.devices.length}/{activeSubscription?.plan.maxDevices ?? "-"}{" "}
              dispositivos utilizados
            </p>
          </Link>

          <Link
            href="/perfil/senha"
            className="bg-surface rounded-lg p-5 hover:bg-white/5 transition"
          >
            <h2 className="font-medium mb-1">Alterar Senha</h2>
            <p className="text-sm text-textMuted/60">
              Atualize sua senha de acesso
            </p>
          </Link>
        </div>
      </div>
    </div>
  );
}
