"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";

export default function ChangePasswordPage() {
  const router = useRouter();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    if (newPassword !== confirmPassword) {
      setError("As senhas não coincidem.");
      return;
    }

    setSaving(true);
    const res = await fetch("/api/users/me/password", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
    setSaving(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Erro ao alterar a senha.");
      return;
    }

    setSuccess(true);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  }

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-sm mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-6">Alterar Senha</h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm mb-1 text-textMuted/80">
              Senha atual
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full rounded-md bg-surface border border-white/10 px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm mb-1 text-textMuted/80">
              Nova senha
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full rounded-md bg-surface border border-white/10 px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm mb-1 text-textMuted/80">
              Confirmar nova senha
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full rounded-md bg-surface border border-white/10 px-3 py-2"
            />
          </div>

          {error && <p className="text-red-400 text-sm">{error}</p>}
          {success && (
            <p className="text-green-400 text-sm">Senha alterada com sucesso.</p>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full bg-primary hover:opacity-90 transition rounded-md py-2 font-semibold"
          >
            {saving ? "Salvando..." : "Alterar senha"}
          </button>
        </form>

        <button
          onClick={() => router.push("/perfil")}
          className="text-sm text-textMuted/60 hover:text-white transition mt-4"
        >
          ← Voltar ao perfil
        </button>
      </div>
    </div>
  );
}
