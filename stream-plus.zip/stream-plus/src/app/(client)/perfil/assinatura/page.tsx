import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import SubscriptionActions from "@/components/SubscriptionActions";

export default async function SubscriptionPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const userId = (session.user as any).id;

  const [plans, activeSubscription] = await Promise.all([
    prisma.plan.findMany({ where: { active: true }, orderBy: { price: "asc" } }),
    prisma.subscription.findFirst({
      where: { userId, status: "ATIVA" },
      include: { plan: true },
      orderBy: { startedAt: "desc" },
    }),
  ]);

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-lg font-semibold mb-1">Minha Assinatura</h1>
        <p className="text-sm text-textMuted/60 mb-8">
          Escolha o plano que melhor combina com você
        </p>

        {activeSubscription && (
          <div className="bg-surface rounded-lg p-5 mb-8 flex items-center justify-between">
            <div>
              <p className="text-sm text-textMuted/60">Plano ativo</p>
              <p className="font-semibold text-lg">
                {activeSubscription.plan.name} · R${" "}
                {Number(activeSubscription.plan.price).toFixed(2)}/mês
              </p>
              <p className="text-xs text-textMuted/50 mt-1">
                Vencimento:{" "}
                {activeSubscription.expiresAt.toLocaleDateString("pt-BR")}
              </p>
            </div>
            <span className="text-xs bg-green-500/20 text-green-400 px-3 py-1 rounded-full">
              Ativa
            </span>
          </div>
        )}

        <div className="grid sm:grid-cols-3 gap-4">
          {plans.map((plan) => {
            const isCurrent = activeSubscription?.planId === plan.id;
            const features = (plan.features as string[] | null) ?? [];

            return (
              <div
                key={plan.id}
                className={`rounded-lg p-5 flex flex-col ${
                  isCurrent
                    ? "bg-surface ring-2 ring-primary"
                    : "bg-surface"
                }`}
              >
                <h2 className="font-semibold mb-1">{plan.name}</h2>
                <p className="text-2xl font-bold mb-4">
                  R$ {Number(plan.price).toFixed(2)}
                  <span className="text-sm font-normal text-textMuted/50">
                    {" "}
                    /mês
                  </span>
                </p>

                <ul className="text-sm space-y-1.5 mb-6 flex-1">
                  {features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2">
                      <span className="text-primary">✓</span>
                      <span className="text-textMuted/80">{feature}</span>
                    </li>
                  ))}
                </ul>

                <SubscriptionActions planId={plan.id} isCurrent={isCurrent} />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
