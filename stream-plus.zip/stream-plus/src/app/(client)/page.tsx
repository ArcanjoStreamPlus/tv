import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import ContentRow from "@/components/ContentRow";
import Link from "next/link";

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id;

  const [featuredMovie, movies, series, watchHistory] = await Promise.all([
    prisma.movie.findFirst({ where: { featured: true } }),
    prisma.movie.findMany({ take: 12, orderBy: { createdAt: "desc" } }),
    prisma.series.findMany({ take: 12, orderBy: { createdAt: "desc" } }),
    userId
      ? prisma.watchHistoryItem.findMany({
          where: { userId },
          take: 8,
          orderBy: { updatedAt: "desc" },
          include: { movie: true, series: true, episode: true },
        })
      : Promise.resolve([]),
  ]);

  const continueWatching = watchHistory
    .map((item) => {
      const content = item.movie ?? item.series;
      if (!content) return null;
      // duração estimada só pra calcular % de progresso quando não temos duração do episódio
      const totalSeconds = item.episode?.durationMin
        ? item.episode.durationMin * 60
        : 60 * 60;
      return {
        id: content.id,
        title: content.title,
        coverUrl: (content as any).coverUrl,
        type: item.movieId ? ("movie" as const) : ("series" as const),
        subtitle: item.episode
          ? `${item.episode.title}`
          : undefined,
        progressPercent: Math.min(
          100,
          Math.round((item.progressSeconds / totalSeconds) * 100)
        ),
      };
    })
    .filter(Boolean) as any[];

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      {featuredMovie && (
        <section className="relative h-[60vh] min-h-[380px] flex items-end">
          {featuredMovie.coverUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={featuredMovie.coverUrl}
              alt={featuredMovie.title}
              className="absolute inset-0 w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />

          <div className="relative z-10 px-4 sm:px-6 pb-10 max-w-2xl">
            <p className="text-sm text-textMuted/70 mb-2">
              {[featuredMovie.genre, featuredMovie.year]
                .filter(Boolean)
                .join(" · ")}
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold mb-3">
              {featuredMovie.title}
            </h1>
            {featuredMovie.description && (
              <p className="text-textMuted/80 text-sm mb-5 line-clamp-3">
                {featuredMovie.description}
              </p>
            )}
            <div className="flex gap-3">
              <Link
                href={`/assistir/movie/${featuredMovie.id}`}
                className="bg-primary hover:opacity-90 transition rounded-md px-5 py-2.5 font-semibold"
              >
                ▶ Assistir
              </Link>
              <Link
                href={`/titulo/movie/${featuredMovie.id}`}
                className="bg-white/10 hover:bg-white/20 transition rounded-md px-5 py-2.5 font-semibold"
              >
                + Minha Lista
              </Link>
            </div>
          </div>
        </section>
      )}

      <div className="pt-6 pb-16">
        {continueWatching.length > 0 && (
          <ContentRow title="Continuar assistindo" items={continueWatching} />
        )}

        <ContentRow
          title="Em destaque"
          items={movies.map((m) => ({
            id: m.id,
            title: m.title,
            coverUrl: m.coverUrl,
            type: "movie" as const,
            subtitle: m.genre ?? undefined,
          }))}
        />

        <ContentRow
          title="Séries para maratonar"
          items={series.map((s) => ({
            id: s.id,
            title: s.title,
            coverUrl: s.coverUrl,
            type: "series" as const,
            subtitle: s.genre ?? undefined,
          }))}
        />
      </div>
    </div>
  );
}
