import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import ContentCard from "@/components/ContentCard";

type MoviesPageProps = {
  searchParams: { genre?: string; year?: string };
};

export default async function MoviesPage({ searchParams }: MoviesPageProps) {
  const [movies, allMovies] = await Promise.all([
    prisma.movie.findMany({
      where: {
        ...(searchParams.genre && { genre: searchParams.genre }),
        ...(searchParams.year && { year: Number(searchParams.year) }),
      },
      orderBy: { title: "asc" },
    }),
    // usado só pra montar as opções de filtro dinamicamente
    prisma.movie.findMany({ select: { genre: true, year: true } }),
  ]);

  const genres = Array.from(
    new Set(allMovies.map((m) => m.genre).filter(Boolean))
  ) as string[];
  const years = Array.from(
    new Set(allMovies.map((m) => m.year).filter(Boolean))
  ).sort((a, b) => (b as number) - (a as number)) as number[];

  return (
    <div className="min-h-screen bg-background text-white">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 flex gap-8">
        <aside className="w-48 flex-shrink-0 hidden md:block">
          <h2 className="text-sm font-semibold mb-3">Filmes</h2>

          <div className="mb-6">
            <p className="text-xs text-textMuted/50 mb-2 uppercase tracking-wide">
              Gênero
            </p>
            <ul className="space-y-1.5 text-sm">
              <FilterLink
                label="Todos"
                active={!searchParams.genre}
                href="/filmes"
              />
              {genres.map((genre) => (
                <FilterLink
                  key={genre}
                  label={genre}
                  active={searchParams.genre === genre}
                  href={`/filmes?genre=${encodeURIComponent(genre)}`}
                />
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs text-textMuted/50 mb-2 uppercase tracking-wide">
              Ano
            </p>
            <ul className="space-y-1.5 text-sm">
              <FilterLink
                label="Todos"
                active={!searchParams.year}
                href="/filmes"
              />
              {years.map((year) => (
                <FilterLink
                  key={year}
                  label={String(year)}
                  active={searchParams.year === String(year)}
                  href={`/filmes?year=${year}`}
                />
              ))}
            </ul>
          </div>
        </aside>

        <main className="flex-1">
          {movies.length === 0 ? (
            <p className="text-textMuted/60">
              Nenhum filme encontrado com esses filtros.
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
              {movies.map((movie) => (
                <ContentCard
                  key={movie.id}
                  id={movie.id}
                  title={movie.title}
                  coverUrl={movie.coverUrl}
                  type="movie"
                  subtitle={[movie.year, movie.genre]
                    .filter(Boolean)
                    .join(" · ")}
                />
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

function FilterLink({
  label,
  href,
  active,
}: {
  label: string;
  href: string;
  active: boolean;
}) {
  return (
    <li>
      <a
        href={href}
        className={
          active
            ? "text-primary font-medium"
            : "text-textMuted/60 hover:text-white transition"
        }
      >
        {label}
      </a>
    </li>
  );
}
