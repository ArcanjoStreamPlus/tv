"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function ClientLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const result = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (result?.error) {
      setError("E-mail ou senha inválidos.");
      return;
    }

    router.push("/");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-textMuted px-4">
      <div className="w-full max-w-sm bg-surface rounded-xl p-8">
        <h1 className="text-2xl font-bold mb-1">Bem-vindo de volta!</h1>
        <p className="text-sm text-textMuted/70 mb-6">
          Faça login para continuar assistindo.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm mb-1">E-mail ou usuário</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-md bg-background border border-white/10 px-3 py-2"
              placeholder="Digite seu e-mail ou usuário"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Senha</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-md bg-background border border-white/10 px-3 py-2"
              placeholder="Digite sua senha"
            />
          </div>

          {error && <p className="text-red-400 text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:opacity-90 transition rounded-md py-2 font-semibold"
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>

        <p className="text-sm text-center mt-4 text-textMuted/70">
          Não tem uma conta?{" "}
          <a href="/assine" className="text-secondary">
            Assine agora
          </a>
        </p>
      </div>
    </div>
  );
}
