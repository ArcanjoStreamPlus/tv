import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Stream Plus — Sua diversão, em um só lugar",
  description:
    "Canais ao vivo, filmes, séries, novelas e animes em um só lugar.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="bg-background text-white antialiased">{children}</body>
    </html>
  );
}
