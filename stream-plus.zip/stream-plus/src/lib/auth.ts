import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@auth/prisma-adapter";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Credenciais",
      credentials: {
        email: { label: "E-mail", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const user = await prisma.user.findUnique({
          where: { email: credentials.email },
        });
        if (!user) return null;

        const passwordValid = await bcrypt.compare(
          credentials.password,
          user.passwordHash
        );
        if (!passwordValid) return null;

        if (user.status === "BLOQUEADO") {
          throw new Error("Sua conta está bloqueada. Fale com o suporte.");
        }

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as any).role;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.id;
        (session.user as any).role = token.role;
      }
      return session;
    },
  },
};

// Papéis que podem acessar o painel administrativo
export const ADMIN_ROLES = [
  "ADMIN_TOTAL",
  "ADMIN_SUPORTE",
  "ADMIN_FINANCEIRO",
  "ADMIN_CONTEUDO",
];

// Permissões por nível de admin, usadas nas rotas de API para bloquear ações
export const ADMIN_PERMISSIONS: Record<string, string[]> = {
  ADMIN_TOTAL: ["*"],
  ADMIN_CONTEUDO: ["catalog:read", "catalog:write"],
  ADMIN_FINANCEIRO: ["payments:read", "payments:write", "subscriptions:read"],
  ADMIN_SUPORTE: ["users:read", "users:write", "devices:read", "devices:write"],
};

export function hasPermission(role: string, permission: string) {
  const perms = ADMIN_PERMISSIONS[role];
  if (!perms) return false;
  return perms.includes("*") || perms.includes(permission);
}
