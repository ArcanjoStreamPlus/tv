import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions, ADMIN_ROLES, hasPermission } from "@/lib/auth";

export async function requireAdmin(permission?: string) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;

  if (!session || !ADMIN_ROLES.includes(role)) {
    return {
      session: null,
      error: NextResponse.json({ error: "Não autorizado" }, { status: 401 }),
    };
  }

  if (permission && !hasPermission(role, permission)) {
    return {
      session: null,
      error: NextResponse.json(
        { error: "Sem permissão para esta ação" },
        { status: 403 }
      ),
    };
  }

  return { session, error: null };
}

export async function requireClient() {
  const session = await getServerSession(authOptions);
  if (!session) {
    return {
      session: null,
      error: NextResponse.json({ error: "Não autenticado" }, { status: 401 }),
    };
  }
  return { session, error: null };
}
