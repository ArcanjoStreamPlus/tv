import { MercadoPagoConfig } from "mercadopago";
import { prisma } from "@/lib/prisma";

/**
 * As chaves (Public Key e Access Token) são cadastradas pelo ADM
 * (tela de Configurações > Pagamentos) e guardadas no banco, não no .env.
 */
export async function getPaymentGatewaySettings() {
  const settings = await prisma.paymentGatewaySettings.findFirst({
    where: { provider: "mercadopago" },
  });

  if (!settings) {
    throw new Error(
      "Mercado Pago não configurado. Cadastre a Public Key e o Access Token no painel ADM."
    );
  }

  return settings;
}

export async function getMercadoPagoClient() {
  const settings = await getPaymentGatewaySettings();
  return new MercadoPagoConfig({ accessToken: settings.accessToken });
}
