import { NextResponse } from "next/server";
import { withAuth } from "next-auth/middleware";

const ADMIN_ROLES = [
  "ADMIN_TOTAL",
  "ADMIN_SUPORTE",
  "ADMIN_FINANCEIRO",
  "ADMIN_CONTEUDO",
];

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const isAdminRoute = req.nextUrl.pathname.startsWith("/admin");
    const isAdminLogin = req.nextUrl.pathname === "/admin/login";

    if (isAdminRoute && !isAdminLogin) {
      if (!token || !ADMIN_ROLES.includes(token.role as string)) {
        return NextResponse.redirect(new URL("/admin/login", req.url));
      }
    }

    return NextResponse.next();
  },
  {
    callbacks: {
      // deixa a checagem de role acima decidir; aqui só exige estar logado
      authorized: ({ token, req }) => {
        if (req.nextUrl.pathname === "/admin/login") return true;
        return !!token;
      },
    },
  }
);

export const config = {
  matcher: ["/admin/:path*"],
};
