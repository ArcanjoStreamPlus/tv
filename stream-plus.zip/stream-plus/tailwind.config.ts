import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "#0B0F1A",
        surface: "#11172A",
        primary: "#6C63FF",
        secondary: "#00D4FF",
        textMuted: "#E5E7EB",
      },
    },
  },
  plugins: [],
} satisfies Config;
