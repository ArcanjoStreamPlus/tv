import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // Admin padrão, só pra você conseguir logar no painel ADM pela primeira vez.
  // TROQUE A SENHA depois de logar.
  const adminPasswordHash = await bcrypt.hash("admin123", 10);
  await prisma.user.upsert({
    where: { email: "admin@streamplus.com" },
    update: {},
    create: {
      name: "Administrador",
      email: "admin@streamplus.com",
      passwordHash: adminPasswordHash,
      role: "ADMIN_TOTAL",
    },
  });

  // Planos, iguais aos da tela "Página de Assinatura"
  await prisma.plan.createMany({
    data: [
      {
        name: "Básico",
        price: 24.9,
        maxDevices: 1,
        maxSimultaneousStream: 1,
        quality: "HD",
        features: ["Filmes e séries", "Qualidade HD", "1 dispositivo"],
      },
      {
        name: "Standard",
        price: 34.9,
        maxDevices: 3,
        maxSimultaneousStream: 2,
        quality: "Full HD",
        features: [
          "Canais ao vivo",
          "Filmes e séries",
          "Qualidade Full HD",
          "Até 3 dispositivos",
        ],
      },
      {
        name: "Premium",
        price: 39.9,
        maxDevices: 5,
        maxSimultaneousStream: 3,
        quality: "Full HD / 4K",
        features: [
          "Canais ao vivo",
          "Filmes e séries",
          "Animes e novelas",
          "Qualidade Full HD / 4K",
          "Até 3 dispositivos simultâneos",
          "Até 5 dispositivos cadastrados",
        ],
      },
    ],
    skipDuplicates: true,
  });

  // Categorias, iguais às da tela "Categorias"
  await prisma.category.createMany({
    data: [
      { name: "Filmes", type: "FILME", icon: "film" },
      { name: "Séries", type: "SERIE", icon: "tv" },
      { name: "Novelas", type: "NOVELA", icon: "heart" },
      { name: "Animes", type: "ANIME", icon: "sparkles" },
      { name: "Canais ao Vivo", type: "CANAL", icon: "radio" },
      { name: "Documentários", type: "DOCUMENTARIO", icon: "camera" },
    ],
    skipDuplicates: true,
  });

  console.log("Seed concluído: admin, planos e categorias criados.");
  console.log("Login ADM -> admin@streamplus.com / admin123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
